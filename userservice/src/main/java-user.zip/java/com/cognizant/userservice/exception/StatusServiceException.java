package com.cognizant.userservice.exception;

public class StatusServiceException  extends Exception  {
    public StatusServiceException(String message) {
        super(message);
    }
}
