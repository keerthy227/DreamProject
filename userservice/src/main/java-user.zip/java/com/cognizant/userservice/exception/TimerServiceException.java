package com.cognizant.userservice.exception;

public class TimerServiceException extends Exception {

    public TimerServiceException(String message) {
        super(message);
    }
}
