package com.cognizant.sessionservice.exception;

public class SessionServiceException extends Exception{
	
	public SessionServiceException(String message) {
		super(message);
	}

}
