package com.cognizant.sessionservice.exception;

public class SessionNotFound extends Exception {
    public SessionNotFound(){
        super("Session Not Found");
    }
}
