import { Component, OnInit, Input } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { Notes } from '../interfaces/notes';
import { Comment } from '../interfaces/comment';
import { SessionService } from '../session.service';
import { Action } from '../interfaces/action';
import { ActionAssigned } from '../interfaces/actionassigned';
import { Template } from '../interfaces/template';
import { AuthServiceService } from '../auth-service.service';

import { TemplateServiceService } from '../template-service.service';


@Component({
  selector: 'app-discussion',
  templateUrl: './discussion.component.html',
  styleUrls: ['./discussion.component.css']
})
export class DiscussionComponent implements OnInit {

  comments: Comment;
  action:Action;
  actionAssigned:ActionAssigned;
  comment = [];
  note: any = [];
  actions:any =[];
  actionsAssigned:any=[];
  count: number = 0;
 sessionId:String = this.sessionService.sessionID;

 @Input()
share:boolean;
 userId = this.service.loggedUserId;
  user: any = [];
  groupNote:any =[];
  users:any = [];
  position: number = 0;
  index: number = 0;
  commentNote: string[] = [];
  notes: Notes;
  data='';
  flag:boolean=false;
  data1='';
  template:Template=this.templateService.template;
  minDate =new Date();
  order: boolean=false;
  icon:boolean=false;
  editId:any=[];
  getVote:any=[];

  constructor(public userService: UserserviceService, public sessionService: SessionService,
              public service:AuthServiceService,public templateService: TemplateServiceService) {
  

   }

  ngOnInit() {
   
  let check={
        retroSessionId:this.sessionId,
        userId:this.userId,
        statusOfScreen:false,
        currentScreen:"screen4"
        };
        this.userService.SaveStatusCheck(check).subscribe();

  this.userService.getUsers(this.sessionId).subscribe(
    (data) => {
      console.log("GetUser",data);
      for(let i in data) {
        this.users.push({
        id:data[i].id,
        userName:data[i].userName,
        displayName:data[i].displayName
        })
      }
      console.log("getUser func",this.users)
    }
  );

  
    this.userService.getAllActions(this.sessionId).subscribe(
      (data) => {
        console.log("action",data);
        for(let i in data) {
          this.actions.push({
            actionId: data[i].actionId,
            action: data[i].action,
            actionUser: data[i].actionUser,
            notes: data[i].notes,
            retroSessionId: data[i].retroSessionId,
            dueDate:data[i].dueDate

          })
        }
        console.log("hi"+this.actions);
      }
    );
this.fetchData();
    this.userService.getAllActionAssigned(this.sessionId).subscribe(
      (data) => {
        console.log("getAllActionAssigned",data);
        for(let i in data) {
          this.actionsAssigned.push({
            id:data[i].id,
            actionId:data[i].actionId,
            actionAssignedUser:data[i].actionAssignedUser,
            retroSessionId:data[i].retroSessionId
          })
        }
        console.log(this.actionsAssigned);
      },
      (error) => {
        alert("Data not returned");
      }
    );

    this.userService.getAllUser(this.sessionId).subscribe(
      (data) => {
        for (let index in data) {
          console.log(data);
          this.user.push({ 
            userId:data[index].userId,
            userName: data[index].userName,
            //displayName:data[index].displayName
          })

        }
        console.log(this.user);

      }

    );

  }
  color(userId) {
   
    this.count = 0;
    for (let i in this.users) {
      this.count++;
      if (this.users[i].id == userId) {

        if (this.count % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.count % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.count % 10 == 3) {
          return "#00e6ac";
        }
        if (this.count % 10 == 4) {
          return "#cc00cc";
        }
        if (this.count % 10 == 5) {
          return "#ff0080";
        }
        if (this.count % 10 == 6) {
          return "#ff9966";
        }
        if (this.count % 10 == 7) {
          return "#ccccb3";
        }
        if (this.count % 10 == 8) {
          return "#dd99ff";
        }
        if (this.count % 10 == 9) {
          return "#b35900";
        }
        if (this.count % 10 == 0) {
          return "#e60073";
        }
      }
    }

  }

 
  setDate(event, action) {
    console.log("Inside date function");
    console.log(event);
    console.log(action);
    action.dueDate = event;
    console.log(action);
   this.userService.saveDueDate(action).subscribe();
  }
 
  next(index: any) {
    if (index < 0 ) {
      index = 0;
    }
    if(index >= this.note.length) {
      index=this.note.length-1;
    }
    this.index = index;
    console.log("index"+this.note[index])
  }
 
  fetchData() {
    this.userService.getAllNotes(this.sessionId).subscribe(
      (data) => {
        this.note.length = 0;
        this.getVote.length=0;
          this.groupNote.length=0;
          for(let index in data){
            console.log(data[index]);
            console.log(data[index].voteList);
            if(data[index].groupId==0){
            this.note.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              user: data[index].user,
              voteList:data[index].voteList,
              commentList: data[index].commentList,
              groupId:data[index].groupId,
              retroSessionId:data[index].retroSessionId
            });
            let count = 0;
            console.log(index);
            console.log(data[index].voteList);
            for(let i = 0; i<data[index].voteList.length;i++) {
              console.log(data[index].voteList[i].votes);
            count = Number(count)+data[index].voteList[i].votes;
            console.log(count);
          }
          if(count != 0) {
            this.getVote.push({
              id: data[index].notesId,
              vote:count
            });
          }
          else {
            this.getVote.push({
              id:data[index].notesId,
              vote:0
            });
          }
          console.log(this.getVote);
            }else{
               this.groupNote.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              user: data[index].user,
              groupId:data[index].groupId
            });
             let editId={id:data[index].groupId};
            if(this.editId.find((value)=>value.id.id == data[index].groupId) === undefined)
              this.editId.push({
               id:editId,
               idShow:true
              });
            
          }
      }
     // this.getCount();
      }
    )
  }
  

  save(event, noteId, user) {
    const content = event.target.innerText.trim();
    if(content!=""){
    this.comments = {
      comment: content,
      commentUser: {
        id: this.userId
      },
      notes: {
        notesId: noteId
      }

    },
      console.log(this.comments);
      this.flag =  false;
    this.userService.saveComments(this.comments).subscribe(
      ()=>{
        event.target.innerText='';
        var input = event.target;
       input.blur();
        this.data = '';
        this.note = [];
        this.actions=[];
        this.user=[];
        this.users=[];
        this.actionsAssigned=[];
        this.ngOnInit();
      }
    );
    }
  }

  // getCount() {
  //   for(let j =0;j<this.note.length;j++) {
  //     for(let i = 0; i<this.note[j].voteList.length;i++) {
  //       this.count = this.count + this.note[j].voteList[i].votes;
  //     }
  //   }
  // }

  delete(actionId) {
    console.log("Inside delete function");
    this.userService.deleteAction(actionId).subscribe(
      ()=>{
        this.data = '';
        this.note = [];
        this.actions=[];
        this.user=[];
        this.users=[];
        this.actionsAssigned=[];
        this.ngOnInit();
      }
    );
  
  }
  
  

  saveAction(event, noteId, user) {
    const content = event.target.innerText.trim();
    if(content!=""){
   

  this.action = {
    action:content,
    actionUser: {
      id: user.id
    },
    notes: {
      notesId: noteId
    },
     retroSessionId:this.sessionId,
  },
    console.log(this.action);
    this.userService.saveAction(this.action).subscribe(
      ()=>{
        event.target.innerText='';
        var input = event.target;
       input.blur();
        this.data1='';
        this.actions=[];
        this.user=[];
        this.users=[];
        this.note = [];
        this.actionsAssigned=[];
        
        this.ngOnInit();
      }
    );
   
    }
}


assignUser(user, actionId) {
  console.log("Inside funtion");
  console.log(user);
  console.log(actionId);
  this.actionAssigned = {
    actionId: actionId,
    actionAssignedUser: {
      id:user
    },
    retroSessionId:this.sessionId,
  },
  console.log("action assigned",this.actionAssigned);
  this.userService.saveActionAssigned(this.actionAssigned).subscribe(
    ()=>{
      this.data1='';
      this.actions=[];
      this.user=[];
      this.users=[];
      this.note = [];
      this.actionsAssigned=[];
      this.ngOnInit();
    }
  );
 
}

show(id:any){
    console.log(this.editId);
    console.log( this.editId.find((value) => value.id.id == id).idShow);
    let shown = this.editId.find((value) => value.id.id == id).idShow ;
    this.editId.find(value => value.id.id == id).idShow = !shown;
    console.log(this.editId);
  }

close(){
  
}

calculateWidth(note:HTMLElement){
    return ((note.offsetWidth/2)-6);
  }


calculate(note:HTMLElement){
     return note.offsetHeight-3;
  }
  onKeydown(event){
    event.preventDefault();
}
}
