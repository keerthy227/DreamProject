import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { SessionService } from '../session.service';
import { Template } from '../interfaces/template';
import { Vote } from '../interfaces/vote';
import { AuthServiceService } from '../auth-service.service';
import { statusCheck } from '../interfaces/statusCheck';
import { TemplateServiceService } from '../template-service.service';

@Component({
  selector: 'app-vote',
  templateUrl: './vote.component.html',
  styleUrls: ['./vote.component.css']
})
export class VoteComponent implements OnInit {

  groupNote:any =[];
  note: any = [];
  v: number;
  timerid:String;
  check:statusCheck;
  count: number = 0;
  count1: number;
  sessionId:String=this.sessionService.sessionID;
  userId = this.service.loggedUserId;
  user:any =[];
  note1: any = [];
  users:any = [];
  note2: any = [];
  note3: any = [];
  vote:Vote;
  counts: number = 0;
  saveVotes:Vote;
  finishedCount:number=0;
  click:boolean=false;
  flag:boolean=false;
  show:boolean=false;
  remainingVotes:number=0;
  template:Template=this.templateService.template;
  interval;
  editId:any=[];

  constructor(public userService: UserserviceService, public sessionService :SessionService,
   public service:AuthServiceService,public templateService: TemplateServiceService) { }

  ngOnInit() {
    this.getAllUser();
    this.getUsers();
    this.getNotes(); 
    this.interval = setInterval(()=>{
        this.getCountOfFinished(this.sessionId);
    },1000)
  }


  getUsers(){
    this.userService.getUsers(this.sessionId).subscribe(
      (data) => {
        console.log("GetUser",data);
        for(let i in data) {
          this.users.push({
          id:data[i].id,
          userName:data[i].userName,
          displayName:data[i].displayName
          })
        }
        console.log("getUser func",this.users)
      }
    );
  }

 getAllUser(){
    this.userService.getAllUser(this.sessionId).subscribe(
      (data)=>{
        for(let index in data){
		  if(data[index].role=='facilitator' && data[index].userId == this.userId){
          this.timerid='facilitator';
          console.log("facilitator");
          }else if(data[index].role !='facilitator' && data[index].userId == this.userId){
            this.timerid='user';
            console.log("user");
          }		  
        }
        this.check={
        retroSessionId:this.sessionId,
        userId:this.userId,
        statusOfScreen:false,
        currentScreen:"screen3",
        role:this.timerid
        };
       this.userService.SaveStatusCheck(this.check).subscribe();
        console.log(this.user);
      },
      (error)=>{
        alert("Error occurs in getting users");
      }
    )
  }



color1(){
  if(this.click == true)
  return "#90EE90";
 
}

getCountOfFinished(sessionId){
    console.log("ncsdnjnsjdjn");  
    this.userService.getStatusCheck(sessionId).subscribe(
      (data)=>{
        if(data != null){
          this.finishedCount=0;
           for(let i in data){
             if(data[i].statusOfScreen == true)
                this.finishedCount++;
             if(data[i].userId == this.userId){
                this.click=data[i].statusOfScreen;
              }
           }
        }
      },
      (error)=>{
        console.log("error in count");
      }
    );
}

  countable(){
  this.check={
    retroSessionId:this.sessionId,
    userId:this.userId,
    statusOfScreen:!this.click,
    currentScreen:"screen3",
    role:this.timerid
  };
  this.userService.SaveStatusCheck(this.check).subscribe();
  
}

  getNotes(){
    this.userService.getAllNotes(this.sessionId).subscribe(
      (data) => {
          this.note.length = 0;
          this.groupNote.length=0;
          for(let index in data){
            if(data[index].groupId==0){
            this.note.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              user:data[index].user,
              voteList:data[index].voteList,
              groupId:data[index].groupId,
              retroSessionId:data[index].retroSessionId
            });
            }else{
               this.groupNote.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              user:data[index].user,
              groupId:data[index].groupId
            });
            let editId={id:data[index].groupId};
            if(this.editId.find((value)=>value.id.id == data[index].groupId) === undefined)
              this.editId.push({
                id:editId,
               idShow:true
              });
          }
        }
        console.log(this.note); 
        console.log(this.groupNote);
        this.getCount();
      }  
    );  
  }

  increment(index: any) {
    if (this.count < 5) {
      this.show=true;
      this.count++;
      this.remainingVotes--;
      this.flag=false;
      let size = this.note[index].voteList.length;
      for(let i=0;i <this.note[index].voteList.length;i++) {
        if(this.note[index].voteList[i].userId == this.userId ) {
          console.log("Inside if of increment");
          this.flag=true;
          this.note[index].voteList[i].votes =  this.note[index].voteList[i].votes + 1;
        }
        this.saveVotes={
          votes:this.note[index].voteList[i].votes,
          notes: {
            notesId:this.note[index].notesId
          },
          userId:this.userId,
          retroSessionId:this.sessionId
        };
      }
      if(this.flag == false) {
        console.log("No data in voteList");
        this.vote = {
          votes : 1,
          notes : {
            notesId : this.note[index].notesId
          },
          userId:this.userId,
          retroSessionId:this.sessionId
        }
        console.log(this.note[index]);
        this.note[index].voteList[size] = this.vote;
        console.log(this.note[index]);
        this.saveVotes={
          votes:this.note[index].voteList[size].votes,
          notes: {
            notesId:this.note[index].notesId
          },
          userId:this.userId,
          retroSessionId:this.sessionId
        };
    }
    this.saveVote();
      }
      console.log(this.note[index].voteList);
      console.log(this.note);
      console.log(this.saveVotes);
      
    }
  
  decrement(index: any) {
    
    if (this.remainingVotes > 0 ) {
      
      this.flag=false;
      let size = this.note[index].voteList.length;
      for(let i=0 ;i < this.note[index].voteList.length;i++) {
        console.log("Inside for");
        if(this.note[index].voteList[i].userId == this.userId && this.note[index].voteList[i].votes != 0) {
          console.log("Inside if of decrement");
          this.flag=true;
          this.count--;
          this.remainingVotes++;
          this.note[index].voteList[i].votes =  this.note[index].voteList[i].votes - 1;
        }
        this.show=true;
        this.saveVotes={
          votes:this.note[index].voteList[i].votes,
          notes: {
            notesId:this.note[index].notesId
          },
          userId:this.userId,
          retroSessionId:this.sessionId
        };
      }     
      }
      else {
        let size = this.note[index].voteList.length;
        for(let i=0 ;i < this.note[index].voteList.length;i++) {
          console.log("Inside for");
          if(this.note[index].voteList[i].userId == this.userId && this.note[index].voteList[i].votes != 0) {
            console.log("Inside if of decrement");
            this.flag=true;
            this.note[index].voteList[i].votes =  this.note[index].voteList[i].votes - 1;
            this.remainingVotes++;
            this.count--;
          }
          this.show=true;
          this.saveVotes={
            votes:this.note[index].voteList[i].votes,
            notes: {
              notesId:this.note[index].notesId
            },
            userId:this.userId,
            retroSessionId:this.sessionId
          };
        } 
      }
      console.log(this.note[index].voteList);
      console.log(this.note);
        this.saveVote();
      }
      
      
  
getCount() {
  for(let j =0;j<this.note.length;j++) {
  for(let i = 0; i<this.note[j].voteList.length;i++) {
    if(this.userId == this.note[j].voteList[i].userId) 
    this.count = this.count + this.note[j].voteList[i].votes;
  }
}
this.remainingVotes = 5 - this.count;
console.log(this.count);
console.log(this.remainingVotes);
}

  saveVote() {
    console.log(this.note);
    console.log(this.saveVotes);
    this.userService.saveVotes(this.saveVotes).subscribe((data) => {
      this.show=false;
      console.log('Data Saved');
    });
  }

  color(userId) {
   
    this.counts = 0;
    for (let i in this.users) {
      this.counts++;
      if (this.users[i].id == userId) {

        if (this.counts % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.counts % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.counts % 10 == 3) {
          return "#00e6ac";
        }
        if (this.counts % 10 == 4) {
          return "#cc00cc";
        }
        if (this.counts % 10 == 5) {
          return "#ff0080";
        }
        if (this.counts % 10 == 6) {
          return "#ff9966";
        }
        if (this.counts % 10 == 7) {
          return "#ccccb3";
        }
        if (this.counts % 10 == 8) {
          return "#dd99ff";
        }
        if (this.counts % 10 == 9) {
          return "#b35900";
        }
        if (this.counts % 10 == 0) {
          return "#e60073";
        }
      }
    }

  }

  calculateWidth(note:HTMLElement){
    return ((note.offsetWidth/2)-6);
  }


calculate(note:HTMLElement){
     return note.offsetHeight-3;
  }

showDropDown(id:any){
    let shown = this.editId.find((value) => value.id.id == id).idShow ;
    this.editId.find(value => value.id.id == id).idShow = !shown;
    
  }
 ngOnDestroy() {
      clearInterval(this.interval);
      this.check={
    retroSessionId:this.sessionId,
    userId:this.userId,
    statusOfScreen:false,
    currentScreen:"screen3",
    role:this.timerid
  };
  this.userService.SaveStatusCheck(this.check).subscribe();
  }
  
  

}
