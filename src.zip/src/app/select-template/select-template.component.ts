import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-select-template',
  templateUrl: './select-template.component.html',
  styleUrls: ['./select-template.component.css']
})
export class SelectTemplateComponent implements OnInit {

  iconname:string="fas fa-user-tag";
  constructor() { }

  ngOnInit() {
  }

}
