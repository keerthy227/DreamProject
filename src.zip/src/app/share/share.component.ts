import { Component, OnInit } from "@angular/core";
import { ActionAssigned } from "../interfaces/actionassigned";
import { FormControl } from "@angular/forms";
import { Action } from "../interfaces/action";
import { AuthServiceService } from "../auth-service.service";
import { UserserviceService } from "../userservice.service";
import { SessionService } from "../session.service";
import { Router } from "@angular/router";
import * as html2pdf from "html2pdf.js";
import { ActionComment } from "../interfaces/actionComment";

@Component({
  selector: "app-share",
  templateUrl: "./share.component.html",
  styleUrls: ["./share.component.css"],
})
export class ShareComponent implements OnInit {
  actionsAssignedArray: any = [];
  actionCommentsArray: any = [];
  existaction: Action[];
  actionComment: ActionComment;
  existActionAssigned: ActionAssigned[];
  currentDate = new Date();
  user: any = [];
  users: any = [];
  actionsAssigned: any = [];
  actionAssigned: ActionAssigned;
  userId: number = this.service.loggedUserId;
  actions: any = [];
  sessionId: String = this.sessionService.sessionID;
  date = new FormControl(new Date());
  serializedDate = new FormControl(new Date().toISOString());
  order: boolean = false;
  minDate = new Date();
  data1 = '';
  index: number = 0;
  position: number = 0;
  data = '';
  action: Action;
  note: any = [];
  share:boolean=true;
  count: number = 0;
  userCount:number =0;
  actionCount: number = 0;
  existCount:number = 0;
  notesCount: number = 0;
  voteCount: number = 0;
  ucount: number = 0;
  existActionComments: ActionComment[];

  teamname: String;
  constructor(
    public service: AuthServiceService,
    public userService: UserserviceService,
    public sessionService: SessionService,
    public router: Router
  ) { }

  ngOnInit() {


    let check = {
      retroSessionId: this.sessionId,
      userId: this.userId,
      statusOfScreen: false,
      currentScreen: "screen5"
    };
    this.userService.SaveStatusCheck(check).subscribe();

    this.userService.getAllActions(this.sessionId).subscribe((data: Action[]) => {
      this.actions = data;
      console.log(this.actions)
      this.actions.forEach(item => {
        if (item.completedDate == null) {
          this.shows.push({
            id: item.actionId,
            click: false
          })
        }
        else {
          this.shows.push({
            id: item.actionId,
            click: true
          })
        }
      });
      this.getActionCount();
    });
    this.userService.getAllNotes(this.sessionId).subscribe((data) => {
      for (let i in data) {
        console.log(data[i]);
        this.note.push({
          notesId: data[i].notesId,
          notes: data[i].notes,
          getNotesId: data[i].getNotesId,
          voteList: data[i].voteList,
          user: data[i].user,
          session: data[i].session,
          commentList: data[i].commentList,
        });
      }

      console.log(this.note);
      this.getNotesCount();
      this.getvoteCount();
    });
    this.teamname = this.sessionService.getteamname;
    this.sessionService
      .getExistingAction(this.teamname, this.service.loggedUserId)
      .subscribe((data: Action[]) => {
        this.existaction = data;
        console.log(this.existaction)
        this.existaction.forEach(item => {
          if (item.completedDate == null) {
            this.show.push({
              id: item.actionId,
              click: false
            })
          }
          else {
            this.show.push({
              id: item.actionId,
              click: true
            })
          }
        });
        this.existCount = this.existaction.length;
      });

    this.userService.getUsers(this.sessionId).subscribe((data) => {
      console.log("GetUser", data);
      for (let i in data) {
        this.users.push({
          id: data[i].id,
          userName: data[i].userName,
          displayName: data[i].displayName,
        });
      }
      console.log("getUser func", this.users);
    });
    this.teamname = this.sessionService.getteamname
    this.sessionService.getExistingActionAssigned(this.teamname, this.service.loggedUserId).subscribe(
      (data: ActionAssigned[]) => {
        console.log("adhfkdslkffakfskdfk", data);
        this.existActionAssigned = data;
        console.log(this.existActionAssigned)

      }

    )

    this.sessionService.getExistingActionComments(this.teamname, this.service.loggedUserId).subscribe(
      (data: ActionComment[]) => {
        console.log("Inside GET func of exixting action comments", data);
        this.existActionComments = data;
        console.log(this.existActionComments)

      }

    )

    this.userService.getAllActionAssigned(this.sessionId).subscribe(
      (data) => {
        console.log(data);
        for (let i in data) {
          this.actionsAssignedArray.push({
            id: data[i].id,
            actionId: data[i].actionId,
            sessionName: data[i].retroSessionId,
            actionAssignedUser: data[i].actionAssignedUser

          }
          )
        }
        console.log(this.actionsAssignedArray);
        //console.log(this.actionCount);
      },
      (error) => {
        alert("Data not returned");
      }
    )

    this.userService.getAllActionComments(this.sessionId).subscribe(
      (data) => {
        console.log(data);
        for (let i in data) {
          this.actionCommentsArray.push({
            actionCommentId: data[i].actionCommentId,
            comments: data[i].comments,
            actionCommentUser: data[i].actionCommentUser,
            action: data[i].action,
            retroSessionId: data[i].retroSessionId
          })
        }
        console.log(this.actionCommentsArray);
      },
      (error) => {
        alert("error in getting actionComments not returned");
      }
    )

    this.userService.getAllUser(this.sessionId).subscribe((data) => {
      for (let index in data) {
        console.log(data);
        this.user.push({
          id: data[index].id,
          userName: data[index].userName,
          displayName: data[index].displayName,
        });
      }
      console.log(this.user);
      this.getCount();
    });
  }

  show: any = [];
  shows: any = [];
  flag: boolean = false
  hide: any;

  toggle(actionId) {
    this.flag = !this.flag;
    let click = this.show.find(i => i.id == actionId).click;
    this.show.find(i => i.id == actionId).click = !click;


    if (click == true) {
      this.existaction.find(i => i.actionId == actionId).completedDate = null;
      console.log(this.currentDate);
      console.log(this.existaction.find(i => i.actionId == actionId));
      this.userService.saveDueDate(this.existaction.find(i => i.actionId == actionId)).subscribe(
      );
    }
    else {
      this.existaction.find(i => i.actionId == actionId).completedDate = this.currentDate;
      console.log(this.currentDate);
      console.log(this.existaction.find(i => i.actionId == actionId));
      this.userService.saveDueDate(this.existaction.find(i => i.actionId == actionId)).subscribe(
      );

    }
  }

  toggles(actionId) {
    this.flag = !this.flag;
    let click = this.shows.find(i => i.id == actionId).click;
    this.shows.find(i => i.id == actionId).click = !click;


    if (click == true) {
      this.actions.find(i => i.actionId == actionId).completedDate = null;
      console.log(this.currentDate);
      console.log(this.actions.find(i => i.actionId == actionId));
      this.userService.saveDueDate(this.actions.find(i => i.actionId == actionId)).subscribe(
      );
    }
    else {
      this.actions.find(i => i.actionId == actionId).completedDate = this.currentDate;
      console.log(this.currentDate);
      console.log(this.actions.find(i => i.actionId == actionId));
      this.userService.saveDueDate(this.actions.find(i => i.actionId == actionId)).subscribe(
      );

    }
  }


  color(userId) {
    this.userCount = 0;
    for (let i in this.users) {
      this.userCount++;
      if (this.users[i].id == userId) {
        if (this.userCount % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.userCount % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.userCount % 10 == 3) {
          return "#00e6ac";
        }
        if (this.userCount % 10 == 4) {
          return "#cc00cc";
        }
        if (this.userCount % 10 == 5) {
          return "#ff0080";
        }
        if (this.userCount % 10 == 6) {
          return "#ff9966";
        }
        if (this.userCount % 10 == 7) {
          return "#ccccb3";
        }
        if (this.userCount % 10 == 8) {
          return "#dd99ff";
        }
        if (this.userCount % 10 == 9) {
          return "#b35900";
        }
        if (this.userCount % 10 == 0) {
          return "#e60073";
        }
      }
    }
  }

  downloadPDF() {
    const element = document.getElementById("content");
    html2pdf()
      .from(element)
      .set({
        margin:[15, 15, 15, 15],
        filename: "file.pdf",
        image: { type: "jpeg" },
        html2canvas: {
          scale: 2,
        },
        jsPDF: { unit: "pt", format: "a4", orientation: "l" },
      })
      .toPdf()
      .get("pdf")
      .then(function (pdf) {
        var totalPages = pdf.internal.getNumberOfPages();
 
        for (let i = 1; i <= totalPages; i++) {
          pdf.setPage(i);
          pdf.setFontSize(10);
          pdf.setTextColor(150);
          pdf.text(
            "Page " + i + " of " + totalPages,
            pdf.internal.pageSize.getWidth() - 100,
            pdf.internal.pageSize.getHeight() - 10
          );
        }
      })
      .save();
  }

  getCount() {
    for (let i in this.user) {
      console.log("inside loop");
      this.count = this.count + 1;
    }
    console.log(this.count);
  }
  getActionCount() {
    for (let index in this.actions) {
      console.log("Inside action loop");
      this.actionCount = this.actionCount + 1;
    }
    console.log(this.actionCount);
  }
  getNotesCount() {
    for (let i in this.note) {
      console.log("Inside notes loop");
      this.notesCount = this.notesCount + 1;
    }
    console.log(this.notesCount);
  }
  getvoteCount() {
    for (let j = 0; j < this.note.length; j++) {
      for (let i = 0; i < this.note[j].voteList.length; i++) {
        this.voteCount = this.voteCount + this.note[j].voteList[i].votes;
      }
    }
  }
  assignUser(user, actionId) {
    console.log("Inside funtion");
    console.log(user);
    console.log(actionId);
    this.actionAssigned = {
      actionId: actionId,
      actionAssignedUser: {
        id: user
      },
      retroSessionId: this.sessionId
    },
      console.log(this.actionAssigned);
    this.userService.saveActionAssigned(this.actionAssigned).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit();
      }
    );

  }

  assignUsers(user, actionId, action) {
    console.log("Inside funtion");
    console.log(user);
    console.log(actionId);
    console.log(action);
    this.actionAssigned = {
      actionId: actionId,
      actionAssignedUser: {
        id: user
      },
      retroSessionId: action.retroSessionId
    },
      console.log(this.actionAssigned);
    this.userService.saveActionAssigned(this.actionAssigned).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit();
      }
    );

  }
  save(event, actionId) {
    console.log(event.target.value);
    console.log(actionId);
    this.actionComment = {
      comments: event.target.value,
      actionCommentUser: {
        id: this.userId
      },
      action: {
        actionId: actionId
      },
      retroSessionId: this.sessionId

    }
    this.userService.saveActionComments(this.actionComment).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionCommentsArray = [];
        this.data = '';
        this.actionsAssignedArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit()
      }
    );
  }
  saveComment(event, action) {
    console.log(event.target.value);
    console.log(action);
    this.actionComment = {
      comments: event.target.value,
      actionCommentUser: {
        id: this.userId
      },
      action: {
        actionId: action.actionId
      },
      retroSessionId: action.retroSessionId

    }
    this.userService.saveActionComments(this.actionComment).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionCommentsArray = [];
        this.data = '';
        this.actionsAssignedArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit()
      }
    );
  }



  saveAction(event) {

    console.log(this.userId);
    this.action = {
      action: this.data1,
      actionUser: {
        id: this.userId
      },
      retroSessionId: this.sessionId


    },
      console.log(this.action);
    this.data1 = '';
    this.actions = [];
    this.user = [];
    //this.note = [];
    this.actionsAssignedArray = [];
    this.userService.saveAction(this.action).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit()
      }
    );


  }

  updateAction(event, action) {
    console.log("Inside Update Action function in ts");
    console.log(event);
    console.log(event.target.innerText);
    console.log(action);
    console.log(action.actionId);

    this.action = {
      actionId: action.actionId,
      action: event.target.innerText,
      actionUser: {
        id: this.userId
      },
      retroSessionId: action.retroSessionId,
      dueDate: action.dueDate


    },
      this.userService.updateAction(this.action).subscribe(
        () => {
          this.actions = [];
          this.user = [];
          this.users = [];
          this.actionsAssignedArray = [];
          this.actionCommentsArray = [];
          this.existActionAssigned = [];
          this.existaction = [];
          this.count = 0;
          this.actionCount = 0;
          this.note = [];
          this.ucount = 0;
          this.voteCount = 0;
          this.notesCount = 0;
          this.ngOnInit()
        }
      );
  }
  next(index: any) {
    if (index < 0) {
      index = 0;
    }
    if (index >= this.actions.length) {
      index = this.actions.length - 1;
    }
    this.index = index;
    console.log("index" + this.actions[index])
  }

  nexts(position: any) {
    if (position < 0) {
      position = 0;
    }
    if (position >= this.existaction.length) {
      position = this.existaction.length - 1;
    }
    this.position = position;
    console.log("position" + position);
    console.log(this.existaction);

  }

  delete(actionId) {
    console.log("Inside delete function");
    this.userService.deleteAction(actionId).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.count = 0;
        this.actionCount = 0;
        this.note = [];
        this.ucount = 0;
        this.voteCount = 0;
        this.notesCount = 0;
        this.ngOnInit();
      }
    );
  }
  close() {

  }


  select(model, action) {
    console.log(model);
    const jsDate = new Date(model.year, model.month - 1, model.day);
    this.setDate(jsDate, action);
  }
  setDate(event, action) {
    console.log(event);
    console.log(action);
    action.dueDate = event;
    console.log(action);
    this.userService.saveDueDate(action).subscribe(

    );
  }

  exit() {
    this.userService.endSession(this.sessionId).subscribe();
    setTimeout(() => {
      this.router.navigateByUrl("/home");
    }, 2000);
  }
}
