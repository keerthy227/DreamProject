import { Component, OnInit, ViewEncapsulation ,} from '@angular/core';
import { AuthServiceService } from '../auth-service.service';
import { SessionService } from '../session.service';
import { Team } from '../interfaces/Team';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Session } from '../interfaces/session';
import { UserserviceService } from '../userservice.service';



@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {
team:Team={
  teamName:"",
  userId:this.service.loggedUserId,
  userName:this.service.loggedUserName,
  displayName:this.service.displayName,
  role:""
};
session:Session={
  userId:this.service.loggedUserId,
  role:"",
  retroSessionId:"",
  retroSessionName:"",
  userName:this.service.loggedUserName
};
joinsession:FormGroup;
teamform:FormGroup
  constructor(private service:AuthServiceService,
    private sessionService:SessionService,private router:Router,
    private userservice:UserserviceService) { }
teamavailable :boolean=false;
userretro:Team[]=[];
getallsession:Session[];
getSession:Session;

  ngOnInit() {
    this.sessionService.allSession(this.service.loggedUserId).subscribe(
      (data:Team[])=>{
      
        if(data==null){
          
          this.teamavailable=true;
        }else{
           this.userretro=data;
           console.log(this.userretro)
        }
      }
    )
 this.joinsession=new FormGroup({
        // username: new FormControl(this.service.loggedUserName,[Validators.required]),
        sessionId:new FormControl("",[Validators.required])
    }); 
     
     this.joinsession.get("sessionId")
    .valueChanges.subscribe(value=>(this.session.retroSessionId=value))



this.teamform=new FormGroup({
      teamName:new FormControl("",[Validators.required]),
     
  });

  this.teamform.get("teamName")
  .valueChanges.subscribe(value=>(this.team.teamName=value))
 
  
  }
  join(){
    console.log(this.session.retroSessionId)
    this.sessionService.getTeam(this.session.retroSessionId).subscribe(
      (data:Session)=>{
        
          this.getSession=data;
          console.log(this.getSession);
        
      }
    );
    
  }

  teams(){
    // this.team.sessionId="this.sessionService.sessionID";
    // this.team.userId=1;
    // this.team={sessionId:"dasdas",userId:1,teamName:}
    this.team.role='facilitator';
    this.sessionService.createteam(this.team).subscribe();
    setTimeout(() => {
      this.ngOnInit();
  }, 2000);
   
  }
// get(teamName){
// this.teamform.get("teamName");
// }
getteamsession(teamname:string){

      this.sessionService.getallteam(teamname);

      // this.sessionService.getteamsession(teamname,this.service.loggedUserId).subscribe(
      //   (data:Session[])=>{
      //       this.getallsession=data;
      //   }
      // );
      // this.router.navigateByUrl('home')

}
get teamName() {
  return this.teamform.get("teamName");
}
jointeam(session:Session){
  
  this.team.role="user";
  this.team.teamName=session.teamName;
  this.sessionService.createteam(this.team).subscribe();

  this.session={role:"user",sessionDate:session.sessionDate,userId:this.service.loggedUserId,userName:this.service.loggedUserName,retroSessionId:session.retroSessionId,retroSessionName:session.retroSessionName,status:session.status,teamName:session.teamName,template:session.template}
  // this.session.sessionDate=session.sessionDate;
  // this.session.userId=this.service.loggedUserId;
  // this.session.userName=this.service.loggedUserName;
  // this.session.role="user";
  this.userservice.join(this.session);
}



}
