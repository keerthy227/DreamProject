import { Component, OnInit, Output, Input, Injectable } from "@angular/core";
import { Session } from "../interfaces/session";
import { FormGroup, FormControl, Validators } from "@angular/forms";
import { AuthServiceService } from "../auth-service.service";
import { SessionService } from "../session.service";
import { Router } from "@angular/router";
import { EventEmitter } from "protractor";
import { UserserviceService } from "../userservice.service";
import { Template } from "../interfaces/template";
import { Team } from "../interfaces/Team";
import { Action } from "../interfaces/action";
import { DatePipe } from "@angular/common";
import { NgbDateStruct, NgbDateAdapter } from "@ng-bootstrap/ng-bootstrap";
import { ActionAssigned } from "../interfaces/actionassigned";
import {Mail } from "../interfaces/mail";
@Injectable()
export class CustomAdapter extends NgbDateAdapter<string> {
  readonly DELIMITER = "-";

  fromModel(value: string | null): NgbDateStruct | null {
    if (value) {
      let date = value.split(this.DELIMITER);
      return {
        day: parseInt(date[0], 10),
        month: parseInt(date[1], 10),
        year: parseInt(date[2], 10),
      };
    }
    return null;
  }

  toModel(date: NgbDateStruct | null): string | null {
    return date
      ? date.day + this.DELIMITER + date.month + this.DELIMITER + date.year
      : null;
  }
}

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.css"],
})
export class HomeComponent implements OnInit {
  startDate = new Date(1990, 0, 1);
  createid : string = Math.random().toString(36).substr(2, 9);
  template: Template;
  Userretros: Session[];
  team: Team;
  minDate = new Date();
  currentretro: Session = null;
  date: Date = new Date();
  session: Session = {
    userId: this.service.loggedUserId,
    role: "",
    retroSessionId: "",
    retroSessionName: "",
    userName: this.service.loggedUserName,
  };
  actionAssigned: ActionAssigned;
  user: any = [];
  actionsAssignedArray: any = [];
  actions: any = [];
  existaction: Action[];
  createsession: FormGroup;
  joinsession: FormGroup;
  teamname: String;
  model: NgbDateStruct;
  members: any;
  count: number;
  users: any = [];
  existActionAssigned: ActionAssigned[];
  actionCommentsArray: any = [];
  sessionId: String = this.sessionService.sessionID;
  emailAddresses:any = [];
  email: String = "";
  mailJson:Mail = {
    fromMail: "",
    toBeSentMail:"",
    subject:"",
    text:""
  }
  currentDate = new Date();
  
  constructor(
    private service: AuthServiceService,
    private sessionService: SessionService,
    public router: Router,
    private userservice: UserserviceService,
    public datepipe: DatePipe,
    private dateAdapter: NgbDateAdapter<string>
  ) {}

  ngOnInit() {
    this.userservice.breadcrum = false;

    this.teamname = this.sessionService.getteamname;
    this.sessionService
      .getteamsession(this.teamname, this.service.loggedUserId)
      .subscribe((data: Session[]) => {
        this.Userretros = data;
        this.todayRetro(this.Userretros);
        console.log("this.Userretros" + this.Userretros);
      });
    this.sessionService
      .getExistingAction(this.teamname, this.service.loggedUserId)
      .subscribe((data: Action[]) => {
        this.existaction = data;
        console.log(this.existaction);
      });
    this.sessionService
      .getExistingActionAssigned(this.teamname, this.service.loggedUserId)
      .subscribe((data: Action[]) => {
        console.log("adhfkdslkffakfskdfk", data);
        this.existActionAssigned = data;
        console.log(this.existActionAssigned);
      });
    // this.userservice.getUsers(this.sessionId).subscribe((data) => {
    //   console.log("GetUser", data);
    //   for (let i in data) {
    //     this.users.push({
    //       id: data[i].id,
    //       userName: data[i].userName,
    //       displayName: data[i].displayName,
    //     });
    //   }
    //   console.log("getUser func", this.users);
    // });

    this.createsession = new FormGroup({
      username: new FormControl(this.service.loggedUserName, [
        Validators.required,
      ]),
      sessionname: new FormControl("", [Validators.required]),
    });
    // this.joinsession=new FormGroup({
    // username: new FormControl(this.service.loggedUserName,[Validators.required]),
    // sessionId:new FormControl("",[Validators.required])
    // });

    // this.createsession.get("username")
    // .valueChanges.subscribe(value=>(this.session.userName=value))

    this.createsession
      .get("sessionname")
      .valueChanges.subscribe(
        (value) => (this.session.retroSessionName = value)
      );

    // this.joinsession.get("username")
    // .valueChanges.subscribe(value=>(this.session.userName=value))
    // this.joinsession.get("sessionId")
    // .valueChanges.subscribe(value=>(this.session.retroSessionId=value))
    this.sessionService.getTeamMembers(this.teamname).subscribe((data: any) => {
      console.log("hiiii" + data);
      this.members = data;
      console.log("members", this.members);
    });

    this.teamname = this.sessionService.getteamname
    this.sessionService.getExistingAction(this.teamname,this.service.loggedUserId).subscribe(
      (data:Action[])=>{
        this.existaction=data;
        console.log(this.existaction)
        this.existaction.forEach(item =>{
          if(item.completedDate == null) {
          this.show.push({
            id:item.actionId,
            click:false
          })
        }
        else {
          this.show.push({
            id:item.actionId,
            click:true
          })
        }
        });
      }
    
    )
  }
  create() {
    this.templatefun;
  }

deleteEmail(email){
    const index: number = this.emailAddresses.indexOf(email);
    if(index != -1){
      this.emailAddresses.splice(index,1);
    }
  }
  addEmail(){
    if(!this.emailAddresses.includes(this.email)){
    console.log(this.email);
    this.emailAddresses.push(this.email);
    }
    console.log(this.emailAddresses);
    this.email ="";
  }
  inviteByEmail(){
    this.mailJson.fromMail="rachurisudheer4@gmail.com";
    this.mailJson.subject = "Invitation to Join Retrospot";
    this.mailJson.text = "Join your organisation using below id "+ this.createid;
    console.log(this.createid);
    console.log((this.mailJson.text));
    this.mailJson.toBeSentMail = this.emailAddresses;
    console.log(this.mailJson.toBeSentMail);
    console.log(this.mailJson);
    this.userservice.sendEmail(this.mailJson).subscribe();
    this.emailAddresses = [];
  }
  
  // join(){
  // this.session.role="user";
  // this.userservice.join(this.session);
  // }

  // templatefun(id:number){
  // this.session.template={id:id};
  // this.session.userId=this.service.loggedUserId;
  // this.session.role="facilitator"
  // this.createid =  Math.random().toString(36).substr(2,9);
  // this.session.retroSessionId=this.createid

  // console.log(this.session);
  // this.userservice.create(this.session)
  // }

  join(session: Session) {
    this.session = session;
    this.session.role = "user";
    this.session.userId = this.service.loggedUserId;
    this.session.userName = this.service.loggedUserName;
    this.userservice.join(this.session);
  }

  templatefun(id: number) {
    this.session.template = { id: id };
    this.session.userId = this.service.loggedUserId;
    this.session.userName = this.service.loggedUserName;
    this.session.sessionDate = new Date();
    this.session.role = "facilitator";
    
    this.session.retroSessionId = this.createid;
    this.session.teamName = this.sessionService.getteamname;
    this.session.status = true;
    console.log(this.session);
    this.userservice.create(this.session);
  }

  color(userId) {
    this.count = 0;
    for (let i in this.members) {
      this.count++;
      if (this.members[i].userId == userId) {
        if (this.count % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.count % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.count % 10 == 3) {
          return "#00e6ac";
        }
        if (this.count % 10 == 4) {
          return "#cc00cc";
        }
        if (this.count % 10 == 5) {
          return "#ff0080";
        }
        if (this.count % 10 == 6) {
          return "#ff9966";
        }
        if (this.count % 10 == 7) {
          return "#ccccb3";
        }
        if (this.count % 10 == 8) {
          return "#dd99ff";
        }
        if (this.count % 10 == 9) {
          return "#b35900";
        }
        if (this.count % 10 == 0) {
          return "#e60073";
        }
      }
    }
  }
  todayRetro(Userretros) {
    // let date:Date =new Date();

    // this.datepipe.transform(date, 'yyyy/MM/dd')
    for (let eachsession of Userretros) {
      if (eachsession.status) {
        this.currentretro = eachsession;
        console.log(this.currentretro);
      }
      // console.log(eachsession);
      //  let date2 = eachsession.sessionDate;
      //  this.datepipe.transform(date2, 'yyyy/MM/dd')
      //  if (date == date2){
      //     if(eachsession.role='facilitator'){
      //       this.currentretro=eachsession;
      //     }else{
      //       this.currentretro=null
      //     }

      //    }
    }
    // return this.currentretro;
  }
  delete(actionId) {
    console.log("Inside delete function");
    this.userservice.deleteAction(actionId).subscribe(() => {
      this.actions = [];
      this.user = [];
      this.users = [];
      this.actionsAssignedArray = [];
      this.actionCommentsArray = [];
      this.existActionAssigned = [];
      this.existaction = [];
      this.ngOnInit();
    });
  }
  setDate(event, action) {
    console.log("Inside date function");
    console.log(event);
    console.log(action);

    action.dueDate = event;
    console.log(action);
    this.userservice.saveDueDate(action).subscribe();
  }
  select(model, action) {
    console.log(model);
    const jsDate = new Date(model.year, model.month - 1, model.day);
    this.setDate(jsDate, action);
  }
  assignUsers(user, actionId, action) {
    console.log("Inside funtion");
    console.log(user);
    console.log(actionId);
    console.log(action);
    (this.actionAssigned = {
      actionId: actionId,
      actionAssignedUser: {
        id: user,
      },
      retroSessionId: action.retroSessionId,
    }),
      console.log(this.actionAssigned);
    this.userservice.saveActionAssigned(this.actionAssigned).subscribe(() => {
      this.actions = [];
      this.user = [];
      this.users = [];
      this.actionsAssignedArray = [];
      this.actionCommentsArray = [];
      this.existActionAssigned = [];
      this.existaction = [];
      this.ngOnInit();
    });
  }

  show:any = [];
  shows:any = [];
  flag:boolean=false
  hide: any;
  toggle(actionId) {
    this.flag=!this.flag;
    let click = this.show.find(i=> i.id == actionId).click;
    this.show.find(i=> i.id == actionId).click=!click;


  if(click == true) {
  this.existaction.find(i=> i.actionId == actionId).completedDate = null;
  console.log(this.currentDate);
  console.log(this.existaction.find(i=>i.actionId == actionId));
  this.userservice.saveDueDate(this.existaction.find(i=>i.actionId == actionId)).subscribe(
    );
  }
  else {
  this.existaction.find(i=> i.actionId == actionId).completedDate =this.currentDate;
  console.log(this.currentDate);
  console.log(this.existaction.find(i=>i.actionId == actionId));
  this.userservice.saveDueDate(this.existaction.find(i=>i.actionId == actionId)).subscribe(
    );
  
  }
  }

}
