import { Component, OnInit, Input } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { FormControl } from '@angular/forms';
import { ActionAssigned } from '../interfaces/actionassigned';
import { AuthServiceService } from '../auth-service.service';
import { Action } from '../interfaces/action';
import { SessionService } from '../session.service';
import { ActionComment } from '../interfaces/actionComment';

@Component({
  selector: 'app-review',
  templateUrl: './review.component.html',
  styleUrls: ['./review.component.css']
})
export class ReviewComponent implements OnInit {


  actionAssigned: ActionAssigned;
  actionComment: ActionComment;
  currentDate = new Date();
  user: any = [];
  actionsAssignedArray: any = [];
  actionCommentsArray: any = [];
  users: any = [];
  userId: number = this.service.loggedUserId;
  actions: any = [];
  sessionId: String = this.sessionService.sessionID;
  date = new FormControl(new Date());
  serializedDate = new FormControl((new Date()).toISOString());
  order: boolean = false;
  minDate = new Date();
  data1 = '';
  index: number = 0;
  position:number =0;
  data = '';
  action: Action;
  teamname:String;
  existaction:Action[];
  existActionAssigned:ActionAssigned[];
  existActionComments:ActionComment[];
  count: number = 0;
  actionCount: any = [];

  @Input() max: any;
  tomorrow = new Date();


  constructor(public service: AuthServiceService, public userService: UserserviceService,
    public sessionService: SessionService) { 
      this.tomorrow.setDate(this.tomorrow.getDate() + 1);
    }


  ngOnInit() {
    let check={
      retroSessionId:this.sessionId,
      userId:this.userId,
      statusOfScreen:false,
      currentScreen:"screen5"
      };
      this.userService.SaveStatusCheck(check).subscribe();

    this.userService.getAllActions(this.sessionId).subscribe(
      // (data) => {
      //   console.log("action", data);
      //   this.actions = data;

      //   console.log("hi" + this.actions);
      // }
      (data:Action[])=>{
        this.actions=data;
        console.log(this.actions)
        this.actions.forEach(item =>{
          if(item.completedDate == null) {
          this.shows.push({
            id:item.actionId,
            click:false
          })
        }
        else {
          this.shows.push({
            id:item.actionId,
            click:true
          })
        }
        });
      }
    )

    this.teamname = this.sessionService.getteamname
    this.sessionService.getExistingAction(this.teamname,this.service.loggedUserId).subscribe(
      (data:Action[])=>{
        this.existaction=data;
        console.log(this.existaction)
        this.existaction.forEach(item =>{
          if(item.completedDate == null) {
          this.show.push({
            id:item.actionId,
            click:false
          })
        }
        else {
          this.show.push({
            id:item.actionId,
            click:true
          })
        }
        });
      }
    
    )
    this.teamname = this.sessionService.getteamname
    this.sessionService.getExistingActionAssigned(this.teamname,this.service.loggedUserId).subscribe(
      (data:ActionAssigned[])=>{
        console.log("adhfkdslkffakfskdfk",data);
        this.existActionAssigned=data;
        console.log(this.existActionAssigned)
       
      }
      
    )

    this.sessionService.getExistingActionComments(this.teamname,this.service.loggedUserId).subscribe(
      (data:ActionComment[])=>{
        console.log("Inside GET func of exixting action comments",data);
        this.existActionComments=data;
        console.log(this.existActionComments)
       
      }
      
    )

    this.userService.getAllActionAssigned(this.sessionId).subscribe(
      (data) => {
        console.log(data);
        for (let i in data) {
          this.actionsAssignedArray.push({
            id: data[i].id,
            actionId: data[i].actionId,
            sessionName: data[i].retroSessionId,
            actionAssignedUser: data[i].actionAssignedUser

          }
          )
         }
        console.log(this.actionsAssignedArray);
        //console.log(this.actionCount);
      },
      (error) => {
        alert("Data not returned");
      }
    )

    this.userService.getAllActionComments(this.sessionId).subscribe(
      (data) => {
        console.log(data);
        for (let i in data) {
          this.actionCommentsArray.push({
            actionCommentId: data[i].actionCommentId,
            comments: data[i].comments,
            actionCommentUser: data[i].actionCommentUser,
            action: data[i].action,
            retroSessionId: data[i].retroSessionId
          })
        }
        console.log(this.actionCommentsArray);
      },
      (error) => {
        alert("error in getting actionComments not returned");
      }
    )

    this.userService.getUsers(this.sessionId).subscribe(
      (data) => {
        console.log("GetUser", data);
        for (let i in data) {
          this.users.push({
            id: data[i].id,
            userName: data[i].userName,
            displayName: data[i].displayName
          })
        }
        console.log("getUser func", this.users)
      }
    );

    
 
  }
  show:any = [];
  shows:any = [];
  flag:boolean=false
  hide: any;

  toggle(actionId) {
    this.flag=!this.flag;
    let click = this.show.find(i=> i.id == actionId).click;
    this.show.find(i=> i.id == actionId).click=!click;


  if(click == true) {
  this.existaction.find(i=> i.actionId == actionId).completedDate = null;
  console.log(this.currentDate);
  console.log(this.existaction.find(i=>i.actionId == actionId));
  this.userService.saveDueDate(this.existaction.find(i=>i.actionId == actionId)).subscribe(
    );
  }
  else {
  this.existaction.find(i=> i.actionId == actionId).completedDate =this.currentDate;
  console.log(this.currentDate);
  console.log(this.existaction.find(i=>i.actionId == actionId));
  this.userService.saveDueDate(this.existaction.find(i=>i.actionId == actionId)).subscribe(
    );
  
  }
  }

  toggles(actionId) {
    this.flag=!this.flag;
    let click = this.shows.find(i=> i.id == actionId).click;
    this.shows.find(i=> i.id == actionId).click=!click;


  if(click == true) {
  this.actions.find(i=> i.actionId == actionId).completedDate = null;
  console.log(this.currentDate);
  console.log(this.actions.find(i=>i.actionId == actionId));
  this.userService.saveDueDate(this.actions.find(i=>i.actionId == actionId)).subscribe(
    );
  }
  else {
  this.actions.find(i=> i.actionId == actionId).completedDate =this.currentDate;
  console.log(this.currentDate);
  console.log(this.actions.find(i=>i.actionId == actionId));
  this.userService.saveDueDate(this.actions.find(i=>i.actionId == actionId)).subscribe(
    );
  
  }
  }

  color(userId) {
   
    this.count = 0;
    for (let i in this.users) {
      this.count++;
      if (this.users[i].id == userId) {

        if (this.count % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.count % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.count % 10 == 3) {
          return "#00e6ac";
        }
        if (this.count % 10 == 4) {
          return "#cc00cc";
        }
        if (this.count % 10 == 5) {
          return "#ff0080";
        }
        if (this.count % 10 == 6) {
          return "#ff9966";
        }
        if (this.count % 10 == 7) {
          return "#ccccb3";
        }
        if (this.count % 10 == 8) {
          return "#dd99ff";
        }
        if (this.count % 10 == 9) {
          return "#b35900";
        }
        if (this.count % 10 == 0) {
          return "#e60073";
        }
      }
    }

  }

  actionUserCount(actionId) {
    console.log("Inside actionUserCount");
    let counts =0;
    for(let i =0;i<this.actionsAssignedArray.length;i++) {
      if(actionId == this.actionsAssignedArray[i].actionId)
      counts++;
    }
    console.log(counts);
    return counts;
  }

  display() {
    alert("assigned");
  }
  setDate(event, action) {
    console.log(event);
    console.log(action);
    action.dueDate = event;
    console.log(action);
    this.userService.saveDueDate(action).subscribe(

    );
  }

  assignUser(user, actionId) {
    console.log("Inside funtion");
    console.log(user);
    console.log(actionId);
    this.actionAssigned = {
      actionId: actionId,
      actionAssignedUser: {
        id: user
      },
      retroSessionId: this.sessionId
    },
      console.log(this.actionAssigned);
    this.userService.saveActionAssigned(this.actionAssigned).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit();
      }
    );

  }

  assignUsers(user, actionId, action) {
    console.log("Inside funtion");
    console.log(user);
    console.log(actionId);
    console.log(action);
    this.actionAssigned = {
      actionId: actionId,
      actionAssignedUser: {
        id: user
      },
      retroSessionId: action.retroSessionId
    },
      console.log(this.actionAssigned);
    this.userService.saveActionAssigned(this.actionAssigned).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit();
      }
    );

  }
  save(event, actionId) {
    console.log(event.target.value);
    console.log(actionId);
    this.actionComment = {
      comments: event.target.value,
      actionCommentUser: {
        id: this.userId
      },
      action: {
        actionId: actionId
      },
      retroSessionId: this.sessionId

    }
    this.userService.saveActionComments(this.actionComment).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionCommentsArray = [];
        this.data = '';
        this.actionsAssignedArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit()
      }
    );
  }
  saveComment(event, action) {
    console.log(event.target.value);
    console.log(action);
    this.actionComment = {
      comments: event.target.value,
      actionCommentUser: {
        id: this.userId
      },
      action: {
        actionId: action.actionId
      },
      retroSessionId: action.retroSessionId

    }
    this.userService.saveActionComments(this.actionComment).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionCommentsArray = [];
        this.data = '';
        this.actionsAssignedArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit()
      }
    );
  }



  saveAction(event) {

    console.log(this.userId);
    this.action = {
      action: this.data1,
      actionUser: {
        id: this.userId
      },
      retroSessionId: this.sessionId


    },
      console.log(this.action);
    this.data1 = '';
    this.actions = [];
    this.user = [];
    //this.note = [];
    this.actionsAssignedArray = [];
    this.userService.saveAction(this.action).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit()
      }
    );


  }

  updateAction(event, action) {
    console.log("Inside Update Action function in ts");
    console.log(event);
    console.log(event.target.innerText);
    console.log(action);
    console.log(action.actionId);

    this.action = {
      actionId: action.actionId,
      action: event.target.innerText,
      actionUser: {
        id: this.userId
      },
      retroSessionId: action.retroSessionId,
      dueDate: action.dueDate


    },
      this.userService.updateAction(this.action).subscribe(
        () => {
          this.actions = [];
          this.user = [];
          this.users = [];
          this.actionsAssignedArray = [];
          this.actionCommentsArray = [];
          this.existActionAssigned = [];
          this.existaction = [];
          this.ngOnInit()
        }
      );
  }
  next(index: any) {
    if (index < 0) {
      index = 0;
    }
    if (index >= this.actions.length) {
      index = this.actions.length - 1;
    }
    this.index = index;
    console.log("index" + this.actions[index])
  }

  nexts(position: any) {
    if (position < 0) {
      position = 0;
    }
    if (position >= this.existaction.length) {
      position = this.existaction.length - 1;
    }
    this.position = position;
    console.log("position" +position);
    console.log(this.existaction);

  }

  delete(actionId) {
    console.log("Inside delete function");
    this.userService.deleteAction(actionId).subscribe(
      () => {
        this.actions = [];
        this.user = [];
        this.users = [];
        this.actionsAssignedArray = [];
        this.actionCommentsArray = [];
        this.existActionAssigned = [];
        this.existaction = [];
        this.ngOnInit();
      }
    );
  }
  close(){
    
  }
  select(model,action){  
    console.log(model);
    const jsDate = new Date(model.year, model.month - 1, model.day);
    this.setDate(jsDate,action);
  }

}
