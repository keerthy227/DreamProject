import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { Template } from '../interfaces/template';
import { SessionService } from '../session.service';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrls: ['./template.component.css']
})
export class TemplateComponent implements OnInit {

  template:Template;
  user: any = [];
  sessionId:String=this.sessionService.sessionID;
  constructor(public userService: UserserviceService,
    public sessionService :SessionService) { }

  ngOnInit() {
    this.sessionService.getTemplate(this.sessionId).subscribe(
      (data:Template)=>{
        console.log(data);
        this.template=data;

      }
    )

  }

  getUser() {
    this.userService.getAllUser(this.sessionId).subscribe(
      (data) => {
        if (Object.keys(data).length != this.user.length) {
          this.user.length = 0;
          for (let index in data) {
            this.user.push({ userName: data[index].userName })
          }
        }
        console.log(this.user);
      }
    )
  }
 
}
