import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { SessionService } from './session.service';
import { Template } from './interfaces/template';


@Injectable({
  providedIn: 'root'
})
export class TemplateServiceService {

  public template:Template;
  public noOfColumns:number;
  constructor(public sessionService :SessionService,
  public router: Router) { }

  getTemplate(sessionId){
  this.sessionService.getTemplate(sessionId).subscribe(
      (data:any)=>{
        console.log(data);
        this.template=data;
        this.noOfColumns=this.template.noOfColumns;
        console.log("len"+this.template.noOfColumns);  
        this.router.navigateByUrl("brainstroming");
       },
       (error)=>{
         alert("Error occurs during template secetion");
       }
       

    );
  }
}
