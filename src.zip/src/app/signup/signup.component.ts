import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl,FormGroup} from '@angular/forms';
import {Validators} from '@angular/forms';
import { User } from '../interfaces/user';
import { UserserviceService} from '../userservice.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  user : User = {
    userName : "",
    password : "",
    email:""
  };
  userForm: FormGroup;
  flag:number =0;
  mailId:String;
  signUpCheck:boolean=false;
  constructor( 
    private service: UserserviceService,
    public router: Router
    ) { }

  
ngOnInit() {
   
  this.service.breadcrum=false;
  this.userForm = new FormGroup({
    username: new FormControl("", [Validators.required]),
    password: new FormControl("", [Validators.required,Validators.minLength(8)]),
    email: new FormControl("",[Validators.required,Validators.email]) 
  });

  this.userForm
    .get("username")
    .valueChanges.subscribe(value => (this.user.userName = value));
  this.userForm
    .get("password")
    .valueChanges.subscribe(value => (this.user.password = value));
    this.userForm
    .get("email")
    .valueChanges.subscribe(value=>(this.user.email = value));
}



onSubmit() {
  console.log(this.user);
  this.mailId=this.user.email;
  if (this.user.password!=null) {
    this.userForm.disable();
    this.signUpCheck=true;
    this.service.addUser(this.user).subscribe(
      ()=>{
        this.flag=0;
        this.router.navigateByUrl("");
      },
      error=>{
        this.signUpCheck=false;
        this.userForm.enable();
        this.flag=1; 
      }

    );
  }
}

get userName() {
  return this.userForm.get("userName");
}
get password() {
  return this.userForm.get("password");
}
get mail(){
  return this.userForm.get("email");

}

}






