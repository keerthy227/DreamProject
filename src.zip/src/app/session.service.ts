import { Injectable } from "@angular/core";
import { Session } from "./interfaces/session";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { UserAuthService } from "./user-auth.service";
import { Team } from "./interfaces/Team";
import { UserserviceService } from "./userservice.service";
import { AuthServiceService } from "./auth-service.service";
import { Router } from "@angular/router";

@Injectable({
  providedIn: "root",
})
export class SessionService {
  getallsession: Session[];
  private baseUrl = "http://localhost:8091/";
  public sessionID: any;
  public sessionName: string;
  constructor(
    private http: HttpClient,
    public service: UserAuthService,
    private authservice: AuthServiceService,
    private router: Router
  ) {}

  session: boolean = false;
  getrole: String = "";
  getteamname: String;
  homeNav: boolean = false;
  create(session: Session) {
    this.sessionID = session.retroSessionId;
    this.sessionName = session.retroSessionName;
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.post(this.baseUrl + "create", session, httpOptions);
  }
  getTemplate(templateid: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.get(this.baseUrl + "template/" + templateid, httpOptions);
  }

  join(session: Session) {
    this.sessionID = session.retroSessionId;
    this.sessionName = session.retroSessionName;
    this.session = true;
    console.log(session);
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.post(this.baseUrl + "join", session, httpOptions);
  }
  createteam(team: Team) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        // Authorization: "Bearer " + this.service.getToken()
      }),
    };
    this.getrole = team.role;
    console.log(team);
    this.getteamname = team.teamName;
    return this.http.post(this.baseUrl + "team", team, httpOptions);
  }

  allSession(id: number) {
    this.homeNav = false;
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.get(this.baseUrl + "getteams/" + id, httpOptions);
  }
  getTeam(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.get(
      this.baseUrl + "getjoiningteam/" + sessionId,
      httpOptions
    );
  }

  getteamsession(teamname, id) {
    this.homeNav = true;
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    this.getteamname = teamname;
    return this.http.get(
      this.baseUrl + "getallteamsession/" + teamname + "/" + id,
      httpOptions
    );
  }

  getExistingAction(teamname, id) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };

    return this.http.get(
      "http://localhost:8080/user/getexistingaction/" + teamname + "/" + id,
      httpOptions
    );
  }

  getExistingActionAssigned(teamname, id) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };

    return this.http.get(
      "http://localhost:8080/user/getexistingactionAssigned/" +
        teamname +
        "/" +
        id,
      httpOptions
    );
  }

  getallteam(teamname: string) {
    this.homeNav = false;
    this.getteamname = teamname;
    // this.getteamsession(teamname,this.authservice.loggedUserId).subscribe(
    //   (data:Session[])=>{
    //     this.getallsession=data;
    //     console.log(this.getallsession);
    //   }
    // );
    this.router.navigateByUrl("home");
  }

  getTeamMembers(teamname: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken(),
      }),
    };
    return this.http.get(
      this.baseUrl + "getteammembers/" + teamname,
      httpOptions
    );
  }

  getExistingActionComments(teamname,id){
  const httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json",
      Authorization: "Bearer " + this.service.getToken()
    })
  };
 
  return this.http.get("http://localhost:8080/user/getExistingActionComments/"+teamname+"/"+id,httpOptions);
}
}
