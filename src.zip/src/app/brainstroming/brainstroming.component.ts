import { Component, OnInit } from '@angular/core';
import {UserserviceService} from '../userservice.service';
import {Notes} from  '../interfaces/notes';
import {User} from  '../interfaces/user';
import { statusCheck } from '../interfaces/statusCheck';
import { AuthServiceService } from '../auth-service.service';
import { SessionService } from '../session.service';
import { Template } from '../interfaces/template';
import { TemplateServiceService } from '../template-service.service';
@Component({
  selector: 'app-brainstroming',
  templateUrl: './brainstroming.component.html',
  styleUrls: ['./brainstroming.component.css']
})
export class BrainstromingComponent implements OnInit {
  id;
  click:boolean=false;
  note:Notes;
  update:boolean=false;
  check:statusCheck;
  user:any=[];
  sessionId:String=this.sessionService.sessionID;
  userId:number=this.service.loggedUserId;
  newNote: any=[];
  dataNote:any =[];
  template:Template=this.templateService.template;
  noOfColumns:number=this.templateService.noOfColumns;
  timerid:String;
  count: number = 0;
  users:any = [];
  interval;
  noteShow:boolean=false;
  finishedCount:number=0;
  
  constructor(public userService:UserserviceService,
              public service:AuthServiceService,
              public sessionService :SessionService,
              public templateService: TemplateServiceService) {
    
  }

  ngOnInit(){
    
    this.interval = setInterval(()=>{
        this.getNotes();
        this.getCountOfFinished(this.sessionId);
    },1000);

   this.getUser();

   for(let i=0;i<this.noOfColumns;i++){
     this.addNote(i);
   }
	 this.userService.getUsers(this.sessionId).subscribe(
      (data) => {
        console.log("GetUser",data);
        for(let i in data) {
          this.users.push({
          id:data[i].id,
          userName:data[i].userName,
          displayName:data[i].displayName
          })
        }
        console.log("getUser func",this.users)
      }
    );
  }
color1(){
  if(this.click == true)
  return "#90EE90";
 
}
color(userId) {
   
  this.count = 0;
  for (let i in this.users) {
    this.count++;
    if (this.users[i].id == userId) {

      if (this.count % 10 == 1) {
        return "#ffb3b3";
      }
      if (this.count % 10 == 2) {
        return "#b3b3ff";
      }
      if (this.count % 10 == 3) {
        return "#00e6ac";
      }
      if (this.count % 10 == 4) {
        return "#cc00cc";
      }
      if (this.count % 10 == 5) {
        return "#ff0080";
      }
      if (this.count % 10 == 6) {
        return "#ff9966";
      }
      if (this.count % 10 == 7) {
        return "#ccccb3";
      }
      if (this.count % 10 == 8) {
        return "#dd99ff";
      }
      if (this.count % 10 == 9) {
        return "#b35900";
      }
      if (this.count % 10 == 0) {
        return "#e60073";
      }
    }
  }

}

countable(){
  this.check={
    retroSessionId:this.sessionId,
    userId:this.userId,
    statusOfScreen:!this.click,
    currentScreen:"screen1",
    role:this.timerid
  };
  this.userService.SaveStatusCheck(this.check).subscribe();
  
}


getCountOfFinished(sessionId){
    console.log("ncsdnjnsjdjn");  
    this.userService.getStatusCheck(sessionId).subscribe(
      (data)=>{
        if(data != null){
          this.finishedCount=0;
           for(let i in data){
             if(data[i].statusOfScreen == true)
                this.finishedCount++;
             if(data[i].userId == this.userId){
                this.click=data[i].statusOfScreen;
                console.log("dcdcdc",this.click);
              }
           }
        }
        console.log(data);
      },
      (error)=>{
        console.log("error in count");
      }
    );
}

  getUser(){
    this.userService.getAllUser(this.sessionId).subscribe(
      (data)=>{
        if(Object.keys(data).length != this.user.length ){
          this.user.length=0;
        for(let index in data){
          this.user.push({userName:data[index].userName,role:data[index].role});
		  if(data[index].role=='facilitator' && data[index].userId == this.userId){
          this.timerid='facilitator';
          console.log("facilitator");
          }else if(data[index].role !='facilitator' && data[index].userId == this.userId){
            this.timerid='user';
            console.log("user");
          }		  
        }
        this.check={
        retroSessionId:this.sessionId,
        userId:this.userId,
        statusOfScreen:false,
        currentScreen:"screen1",
        role:this.timerid
        };
       this.userService.SaveStatusCheck(this.check).subscribe();
       console.log(this.check);
        }
        console.log(this.user);
      },
      (error)=>{
        console.log("Error occurs in getting users");
      }
    )
  }

  getNotes(){
    this.userService.getAllNotes(this.sessionId).subscribe(
      (data:any) => {
        if(Object.keys(data).length != this.dataNote.length ){
          this.dataNote.length = 0;
          for(let index in data){
            this.dataNote.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              userId:data[index].user.id,
              displayName:data[index].user.displayName
            });
            console.log("note",this.dataNote);
          }
          
        }
      },
      (error)=>{
        console.log("error");
      }
    );
  }
  
  addNote (id:number) {
          this.newNote.push({
            index:this.newNote.length,
            id:id,
            content:''
          });  
          console.log(this.newNote);
    
  };
   
  onDismiss(noteId){
         this.userService.removeNote(noteId).subscribe(
           (data)=>{
             
           },(error)=>{
             console.log("error occurs during delete");
           }
         );
       }
    
  onKeydown(event){
    event.preventDefault();
}

  saveNote(event){
    const value = event.target.id.split("+");
    const content = event.target.innerText.trim();
    const id = Number(value[0])+1;
    const index = Number(value[1]);
    if(content!=""){
      this.note={
      getNotesId:id,
      notes:content,
      user:{
        id:this.userId
      },
      retroSessionId:this.sessionId
      }
    console.log(this.note);
    this.userService.saveNotes(this.note).subscribe(
      (data)=>{
        event.target.innerText='';
         var input = event.target;
        input.blur();
      },
      (error)=>{
        console.log("error in note");
      }
    );
  }
  
}

updateNote(event){
    const value = event.target.id.split("+");
    const content = event.target.innerText.trim();
    const id = Number(value[0])+1;
    const index = Number(value[1]);
    if(content!=""){
    this.note={
      notesId:index,
      getNotesId:id,
      notes:content,
      retroSessionId:this.sessionId,
      user:{
        id:this.userId
      }
    }
    this.userService.saveNotes(this.note).subscribe(
      (data)=>{
        var input = event.target;
        input.blur();
      },
      (error)=>{
        console.log("error in updated");
      }
    );
    }
}
  
  position(button:HTMLElement){
    return (button.offsetWidth/2)
  }

  ngOnDestroy() {
      clearInterval(this.interval);
  this.check={
    retroSessionId:this.sessionId,
    userId:this.userId,
    statusOfScreen:false,
    currentScreen:"screen1",
    role:this.timerid
  };
  console.log(this.check);
  this.userService.SaveStatusCheck(this.check).subscribe();
  console.log("hsvshcshcg schgsjh jcgshjgs sgjj");

  }
}
  

