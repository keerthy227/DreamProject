import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BrainstromingComponent } from './brainstroming.component';

describe('BrainstromingComponent', () => {
  let component: BrainstromingComponent;
  let fixture: ComponentFixture<BrainstromingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BrainstromingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BrainstromingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
