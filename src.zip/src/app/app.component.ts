import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { SessionService } from './session.service';
import { UserserviceService } from './userservice.service';
import { AuthServiceService } from './auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'retro';
//  @Input() createform:boolean;
//  @Input() joinform:boolean ;

// recievedChild:string;

// getMessage(message:string){
//   this.recievedChild = message;
// }
constructor(public userservice:UserserviceService, public sessionservice:SessionService,public service:AuthServiceService) { }
}
