import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { User } from './interfaces/user';
import { Session } from './interfaces/session';
import { Notes } from '../app/interfaces/notes';
import { Comment } from '../app/interfaces/comment';
import { Router } from '@angular/router';
import { Action } from './interfaces/action';
import { UserAuthService } from './user-auth.service';
import { SessionService } from './session.service';
import { ActionAssigned } from './interfaces/actionassigned';
import { Team } from './interfaces/Team';
import { Vote } from './interfaces/Vote';
import { ActionComment } from './interfaces/actionComment';
import { Timer } from './interfaces/timer';
import { statusCheck } from './interfaces/statusCheck';
import { TemplateServiceService } from './template-service.service';
@Injectable({
  providedIn: 'root'
})


export class UserserviceService {

  breadcrum: boolean = false
  team:Team;

  private baseUrl = "http://localhost:1112/registration";
  private registerUrl = this.baseUrl + "RegistrationService/";
  private userUrl = this.baseUrl + "UserService/"

  constructor(
    private http: HttpClient,
    public service: UserAuthService,
    private sessionservice: SessionService,
    public router: Router, public templateService: TemplateServiceService) { }

  create(session: Session) {
    this.sessionservice.create(session).subscribe(
      () => {
        this.breadcrum = true;
        this.templateService.getTemplate(session.retroSessionId);
      }
    )
  }

  getTemplate(sessionId:String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    console.log("sessionID for " + sessionId);
    return this.http.get("http://localhost:8080/user/template/"+sessionId, httpOptions);
    
  }

  getAllActions(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/action/" + sessionId, httpOptions);

  }

  saveActionComments(actionComment : ActionComment){
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    console.log("post menthod of actioncomment");
    return this.http.post("http://localhost:8080/user/postActionComments", actionComment, httpOptions); 
  }

  getAllActionComments(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/getActionComments/" + sessionId, httpOptions);

  }
  updateAction(action:Action) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.put("http://localhost:8080/user/updateAction", action, httpOptions);
  }

  join(session: Session) {
    this.sessionservice.join(session).subscribe(
      (data) => {
        this.breadcrum = true;
        this.templateService.getTemplate(session.retroSessionId);
      }
    )
    
    // this.team.userId=session.userId;
    // this.sessionservice.createteam(this.team);
    
  }
  addUser(newuser: User) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    console.log("Adduser" + newuser);
    return this.http.post("http://localhost:8095/users", newuser, httpOptions);
  }

  getUser(id: number) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.http.get(this.userUrl + "user/" + id, httpOptions);

  }

  updateUser(user: User) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json",
        Authorization: "Bearer " + this.service.getToken()
      })
    };
    return this.http.put(this.userUrl + "user/update", user, httpOptions);
  }

  getUsers(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/getUser/" + sessionId, httpOptions);

  }

  saveNotes(note: Notes) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.post("http://localhost:8080/user/store", note, httpOptions);
  }

  

  saveDueDate(action:Action) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.put("http://localhost:8080/user/updateAction", action, httpOptions);
  }


  saveComments(comments: Comment) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    console.log("post method");
    return this.http.post("http://localhost:8080/user/postComment", comments, httpOptions);
  }

  saveAction(action: Action) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    console.log("post method of action");
    return this.http.post("http://localhost:8080/user/postAction", action, httpOptions);
  }

  saveActionAssigned(actionAssigned: ActionAssigned) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    console.log("post method of action");
    return this.http.post("http://localhost:8080/user/postActionAssigned", actionAssigned, httpOptions);
  }

  removeNote(id: any) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.post("http://localhost:8080/user/remove", id, httpOptions);
  }

  getAllUser(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/" + sessionId, httpOptions);

  }

  getAllActionAssigned(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/getActionAssigned/" + sessionId, httpOptions);

  }

  getAllComments(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/getComments/" + sessionId, httpOptions);

  }

  groupCount(sessionId:String){
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/count/" + sessionId, httpOptions);
  }

  groupNotes(note: Notes) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.put("http://localhost:8080/user/group", note, httpOptions);
  }

  ungroupNotes(note: Notes) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.put("http://localhost:8080/user/ungroup", note, httpOptions);
  }
  deleteAction(actionId : number ) {
    const httpOptions = {
      headers: new HttpHeaders({ 
        "Content-Type": "application/json"
      })
    };
    return this.http.post("http://localhost:8080/user/removeAction",actionId, httpOptions);
  }

  getAllNotes(sessionId: String) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.get("http://localhost:8080/user/notes/" + sessionId, httpOptions);

  }
  
 
  endSession(sessionID:String){
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    return this.http.put("http://localhost:8080/user/endsession",sessionID, httpOptions);
  }

  saveVotes(vote:Vote) {
    const httpOptions = {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    };
    console.log(vote);
    return this.http.put("http://localhost:8080/user/postVote", vote, httpOptions);
  }

  SaveTime(time:Timer){
    const httpOptions = {
       headers: new HttpHeaders({
         "Content-Type": "application/json"
       })
     };
     return this.http.post("http://localhost:8080/timer", time, httpOptions);
   }

   getTime(sessionId:String){
     const httpOptions = {
       headers: new HttpHeaders({
         "Content-Type": "application/json"
       })
     };
     return this.http.get("http://localhost:8080/timer/" + sessionId, httpOptions);
   }

   SaveStatusCheck(status:statusCheck){
    const httpOptions = {
       headers: new HttpHeaders({
         "Content-Type": "application/json"
       })
     };
     return this.http.post("http://localhost:8080/status", status, httpOptions);
   }

   getStatusCheck(sessionId:String){
     const httpOptions = {
       headers: new HttpHeaders({
         "Content-Type": "application/json"
       })
     };
     return this.http.get("http://localhost:8080/status/" + sessionId, httpOptions);
   }
   
   sendEmail(mailJson){
     console.log("before http call:- "+mailJson);
      const httpOptions = {
       headers: new HttpHeaders({
         "Content-Type": "application/json"
       })
     };
      return this.http.post("http://localhost:8080/user/sendEmail" , mailJson, httpOptions);
   }

}
