import { Injectable } from '@angular/core';
import { BehaviorSubject } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class TimerServiceService {
  
  public myData: BehaviorSubject<String[]> = new BehaviorSubject<String[]>([]);
  timerid:any=null;
  status:any=null;
  time:any=null;
  data:any=[];
  constructor() { }

  load(session){ 
    if(null != JSON.parse(localStorage.getItem(session)))
    this.timerid=JSON.parse(localStorage.getItem(session)).timer;
    else
    return null;
    return this.timerid;
  }

  statusOfTimer(session){
    if(null != JSON.parse(localStorage.getItem(session)))
    this.status=JSON.parse(localStorage.getItem(session)).status;
    else
    return null;
    return this.status;
  }

  setTime(session){
    if(null != JSON.parse(localStorage.getItem(session)))
    this.time=JSON.parse(localStorage.getItem(session)).setTime;
    else
    return null;
    return this.time;
  }

  timer(session,min,value,time){
    this.data={
      timer:min,
      status:value,
      setTime:time
    };
    localStorage.setItem(session, JSON.stringify(this.data));
  }

  remove(session){
    localStorage.removeItem(session);
    console.log(JSON.parse(localStorage.getItem(session)));
  }
}
