import { Component, OnInit, Input } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { SessionService } from '../session.service';

import { Timer } from '../interfaces/timer';
@Component({
  selector: 'app-timer',
  templateUrl: './timer.component.html',
  styleUrls: ['./timer.component.css']
})
export class TimerComponent implements OnInit {

  constructor(public userService: UserserviceService,
    public sessionService: SessionService) { }


  @Input()
  role: String;
  intervalGetDuration;
  intervalCheckTime;
  intervalCheckStatus;
  timeLeft: number;
  intervalTimer;
  min: number = 0;
  sec: number = 0;
  skip: boolean = false;
  show: boolean = false;
  flag:boolean=false;
  scroll: boolean = false;
  sessionId: String = this.sessionService.sessionID;
  setTime: any;
  findMin:any;
  close: boolean = false;
  timeSet: Timer;
  Minutes: Timer;


  ngOnInit(): void {
     if (this.role == 'user'){
       this.intervalGetDuration = setInterval(() =>{
       this.getDuration();
      },1000);
      this.initial();
     }
    
  }

  initial() {
      console.log(this.role);
      this.intervalCheckTime = setInterval(() => {
        console.log("interval 1");
        console.log(this.Minutes);
        if (this.Minutes != null) {
          this.min = Number(this.Minutes.min);
          if (this.min != 0) {
            let currentTime = String(new Date()).split(" ")[4];
            this.setTime = this.Minutes.setTime;
            if (currentTime == this.setTime) {
              this.findMin=this.min;
              this.time(this.min * 60);
              this.flag=true;
            }
            else {
              let setTimeForMin = ((Number(this.setTime.split(":")[0]) * 60 * 60) + (Number(this.setTime.split(":")[1]) * 60)
                + (Number(this.setTime.split(":")[2])));

              let currentTimeForMin = ((Number(currentTime.split(":")[0]) * 60 * 60) + (Number(currentTime.split(":")[1]) * 60)
                + (Number(currentTime.split(":")[2])));

              let relativeMin = currentTimeForMin - setTimeForMin;
              this.findMin = this.min;
              this.min = this.findMin - Math.trunc(relativeMin / 60) - 1;
              this.sec = 60 - (relativeMin % 60);
              this.time((this.findMin * 60) - relativeMin);
            }
          }
        }
      }, 1000);
  }


  startTimer(e) {
    console.log(e);
    this.timeLeft = 0;
    this.sec = 0;
    this.min = 0;
    this.skip = false;
    this.show = false;
    this.scroll = false;
    this.min = Number(e.target.innerText.split(" ")[0]);
    this.timeSet = {
      min: this.min,
      sessionId: this.sessionId
    };
    this.userService.SaveTime(this.timeSet).subscribe(
      () => {
        this.time(this.min * 60);
      }
    );


  }

  getDuration(){
     this.userService.getTime(this.sessionId).subscribe(
          (data) => {
            this.Minutes = data;
            console.log(this.Minutes);
          }
        );
  }

  checkDuration(){
       if (0 == this.Minutes.min) {
          this.reset();
        }
        if(this.findMin != Number(this.Minutes.min) ||
        this.setTime != this.Minutes.setTime){
          this.sec=0;
          this.min = this.Minutes.min;
          this.setTime = this.Minutes.setTime;
          this.findMin=this.min;
          this.time(this.Minutes.min * 60); 
        }
  }



  time(min) {
    clearInterval(this.intervalTimer);
    clearInterval(this.intervalCheckStatus);
    console.log(this.min);
    if (this.role == 'user') {
      clearInterval(this.intervalCheckTime);
    }
    this.scroll = false;
    this.skip = true;
    this.show = false;
    this.timeLeft = min;
     console.log(this.timeLeft);
    this.intervalTimer = setInterval(() => {
      if (this.role == 'user' && this.flag== false) {
        this.checkDuration();
      }
      if (this.timeLeft > 0) {
        console.log(this.timeLeft);
        if (this.timeLeft % 60 == 0) {
          this.sec = 60;
          this.min--;
        }
        if (this.timeLeft < 11) {
          this.show = true;
        }
        this.timeLeft--;
        this.sec--;
        this.flag=false;
      } else {
        if (this.role == 'facilitator') {
          clearInterval(this.intervalTimer);
        } else {
          clearInterval(this.intervalTimer);
          this.intervalCheckStatus = setInterval(() => {
            this.checkDuration();
          }, 1000);
        }
      }
    }, 1000);
  }

  reset() {
    if (this.role == 'user') {
      clearInterval(this.intervalCheckStatus);
      clearInterval(this.intervalTimer);
      clearInterval(this.intervalGetDuration);
      this.timeLeft = 0;
      this.sec = 0;
      this.min = 0;
      this.skip = false;
      this.show = false;
      this.scroll = false;
      this.ngOnInit();
    } else {
      this.ngOnDestroy();
    }
  }

  submit() {
    this.scroll = !this.scroll;
  }

  ngOnDestroy() {
    if (this.role == 'user') {
      clearInterval(this.intervalCheckTime);
      clearInterval(this.intervalGetDuration);
      clearInterval(this.intervalCheckTime);
      this.timeLeft = 0;
      this.sec = 0;
      this.min = 0;
      this.skip = false;
      this.show = false;
      this.scroll = false;
    }
    else {
      this.timeSet = {
        min: 0,
        sessionId: this.sessionId
      };
      this.userService.SaveTime(this.timeSet).subscribe(
        () => {
          clearInterval(this.intervalTimer);
          this.timeLeft = 0;
          this.sec = 0;
          this.min = 0;
          this.skip = false;
          this.show = false;
          this.scroll = false;
        }
      );

    }
  }

}
