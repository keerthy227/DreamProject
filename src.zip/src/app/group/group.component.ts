import { Component, OnInit, Input, NgModule, EventEmitter, Output } from '@angular/core';
import { Notes } from '../interfaces/notes';
import { CdkDragDrop, moveItemInArray, transferArrayItem, CdkDragEnter, CdkDragExit } from '@angular/cdk/drag-drop';
import {UserserviceService} from '../userservice.service';
import { AuthServiceService } from '../auth-service.service';
import { SessionService } from '../session.service';
import { TemplateServiceService } from '../template-service.service';

import { Template } from '../interfaces/template';
@Component({

  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {


	
  template:Template=this.templateService.template;
  id:any;
  editId:any=[];
  dataNote:any=[];
  groupNote:any=[];
  groupBackendNote:any=[];
  dragdata:number=0;
  editdata:number=0;
  groupid:number;
  userId:number=this.service.loggedUserId;
  count :number;
  users:any = [];
  groupTitle:any;
  sessionId:String= this.sessionService.sessionID;

  constructor(public userService:UserserviceService,
              public service:AuthServiceService,
              public sessionService :SessionService,
              public templateService: TemplateServiceService) { }
  ngOnInit() {
       
	     let check={
        retroSessionId:this.sessionId,
        userId:this.userId,
        statusOfScreen:false,
        currentScreen:"screen2"
        };
        this.userService.SaveStatusCheck(check).subscribe();
		
        console.log(this.groupTitle);
            
        this.userService.getUsers(this.sessionId).subscribe(
              (data) => {
        console.log("GetUser",data);
        for(let i in data) {
        this.users.push({
        id:data[i].id,
        userName:data[i].userName,
        displayName:data[i].displayName
                  })
                }
        console.log("getUser func",this.users)
              }
            );



    this.userService.getAllNotes(this.sessionId).subscribe(
      (data:any) => {
          this.dataNote.length = 0;
          this.groupNote.length=0;
          this.editId.length=0;
          for(let index in data){
            if(data[index].groupId==0){
            this.dataNote.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              user:data[index].user,
              groupId:data[index].groupId,
              retroSessionId:data[index].retroSessionId
            });
            }else{
               this.groupNote.push({
              notesId:data[index].notesId,
              notes:data[index].notes,
              getNotesId:data[index].getNotesId,
              groupId:data[index].groupId,
              user:data[index].user,
            });
            let editId={id:data[index].groupId};
            if(this.editId.find((value)=>value.id.id == data[index].groupId) === undefined)
              this.editId.push({
                id:editId,
               idShow:true
              });
            }
            console.log("editId",this.editId);
            console.log("note",this.dataNote);
            console.log("group",this.groupNote);
          }
      },
      (error)=>{
        alert("error");
      }
    );
  }

//   dragStarted(event){
//   console.log(event.source.data.notesId);
//     this.groupBackendNote.push({
//               notesId:event.source.data.notesId,
//               groupId:0,
//             });
//      this.userService.groupNotes(this.groupBackendNote).subscribe(
//       ()=>{
//           this.dragdata=0;
//           this.editdata=0;
//           this.ngOnInit();
//           }
//     );
// }


  
  color(userId) {
   
    this.count = 0;
    for (let i in this.users) {
      this.count++;
      if (this.users[i].id == userId) {
 
        if (this.count % 10 == 1) {
          return "#ffb3b3";
        }
        if (this.count % 10 == 2) {
          return "#b3b3ff";
        }
        if (this.count % 10 == 3) {
          return "#00e6ac";
        }
        if (this.count % 10 == 4) {
          return "#cc00cc";
        }
        if (this.count % 10 == 5) {
          return "#ff0080";
        }
        if (this.count % 10 == 6) {
          return "#ff9966";
        }
        if (this.count % 10 == 7) {
          return "#ccccb3";
        }
        if (this.count % 10 == 8) {
          return "#dd99ff";
        }
        if (this.count % 10 == 9) {
          return "#b35900";
        }
        if (this.count % 10 == 0) {
          return "#e60073";
        }
      }
    }
 
  }


  drop(event: CdkDragDrop<Notes[]>) {
     console.log(event);
   if (event.previousIndex != event.currentIndex) {
     this.id=event.container.data[event.currentIndex].notesId;
     console.log("sbdhsdgvs",this.id);
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
      let newId=event.container.data[event.currentIndex].notesId;
      console.log("xcdcd",newId)
      if(this.editId.find(i=> i.id.id === newId) != undefined){
          this.groupid=this.editId.find(i=> i.id.id == newId).id.id;
          let group = this.groupNote.filter(z => z.groupId == this.groupid);
          group.forEach(item =>{
            this.groupNote.find(i=> i.notesId == item.notesId).groupId=this.id;
          });
      }
      this.groupNote.push({
      notesId:event.container.data[event.currentIndex].notesId,
      getNotesId:event.container.data[event.currentIndex].getNotesId,
      notes:event.container.data[event.currentIndex].notes,
      groupId:this.id
    });
      
    this.dragdata=this.id;
    this.edit( this.dragdata);
    this.dataNote.splice(event.currentIndex,1);
  }
    
  }


      
  groupFunction(id:number){
    console.log("id"+id);
     console.log("note"+this.groupNote);
     this.groupBackendNote.length=0;
     for(let index in this.groupNote){
            if(this.groupNote[index].groupId == id){
            this.groupBackendNote.push({
              notesId:this.groupNote[index].notesId,
              groupId:this.groupNote[index].groupId,
              // groupTitle:this.groupNote[index].groupName,
            });
          }
     }
      console.log("note"+this.groupBackendNote);
    this.userService.groupNotes(this.groupBackendNote).subscribe(
      ()=>{
          this.dragdata=0;
          this.editdata=0;
        this.ngOnInit();
      }
    );
    
  }

  ungroupFunction(id:number){
       console.log("id1"+id);
     console.log("note1"+this.groupNote);
     this.groupBackendNote.length=0;
     for(let index in this.groupNote){
            if(this.groupNote[index].groupId == id){
            this.groupBackendNote.push({
              notesId:this.groupNote[index].notesId,
              groupId:this.groupNote[index].groupId,
            });
          }
     }
      console.log("note1"+this.groupBackendNote);
    this.userService.ungroupNotes(this.groupBackendNote).subscribe(
      ()=>{
          this.dragdata=0;
          this.editdata=0;
        this.ngOnInit();
      }
    );
  }
  
  save(event){
    console.log(event);
  }

  edit(notesId:any){
      this.editdata=notesId;;
      console.log(this.editdata);
  }

  getConnectedList(){
    return this.dataNote.map(x => `${x.getNotesId}`);
  }

  show(id:any){
    let shown = this.editId.find((value) => value.id.id == id).idShow ;
    this.editId.find(value => value.id.id == id).idShow = !shown;
    
  }

 calculateWidth(note:HTMLElement){
    return ((note.offsetWidth/2)-6);
  }


calculate(note:HTMLElement){
     return note.offsetHeight-3;
  }
  
}

 