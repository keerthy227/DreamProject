import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ideas',
  templateUrl: './ideas.component.html',
  styleUrls: ['./ideas.component.css']
})
export class IdeasComponent implements OnInit {

  note1 = [];
  note2 = [];
  note3  = [];
  recognition:any;
  constructor() {
   
  }

  ngOnInit(){
   
  }
  
  addNote (id:number) {
    if(id === 1){
    this.note1.push({ id: this.note1.length + 1,content:'' });
    }

    if(id === 2){
      this.note2.push({ id: this.note2.length + 1,content:'' });
      }

      if(id === 3){
        this.note3.push({ id: this.note3.length + 1,content:'' });
        }
  };
  
  
  
  onDismiss(event){
    console.log('event emitted ',event
    );
    const id = event.id;
    // this.dismiss1(event);
    if(id === 1){
      this.note1.splice(event.index,1);
      }
  
      if(id === 2){
        this.note2.splice(event.index,1);
        }
  
        if(id === 3){
          this.note3.splice(event.index,1);
          }
  }

   record(event) {
    this.recognition.start();
    this.addNote(event);
  }

 
}


