import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { UserserviceService} from '../userservice.service';
import { AuthServiceService} from '../auth-service.service';
import { User } from '../interfaces/user';
import {NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm;
  authenticated: Boolean = true;
  loggedUser: User;
  
  model: NgbDateStruct;

constructor(public authService:AuthServiceService, public service: AuthServiceService,
 public router: Router,private userService:UserserviceService) {}

ngOnInit() {

  this.userService.breadcrum=false;
  this.service.loginCheck=false;
  this.service.Invalid=false;
  this.authService.logOut();
  this.loggedUser = {
    userName : "",
    password : "",
    email:""
  };
}
onLogin() {
  console.log(this.loggedUser.userName);
  this.service.authenticateUser(
    this.loggedUser.userName,
    this.loggedUser.password
  );
  
}



}

