import { NgModule, Component } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LoginComponent } from "./login/login.component";
import { SignupComponent } from "./signup/signup.component";
import { IdeasComponent } from "./ideas/ideas.component";
import { AuthGuardGuard } from "./auth-guard.guard";
import { HomeComponent } from "./home/home.component";
import { VoteComponent } from "./vote/vote.component";
import { BrainstromingComponent } from "./brainstroming/brainstroming.component";
import { GroupComponent } from "./group/group.component";
import { DiscussionComponent } from "./discussion/discussion.component";
import { SelectTemplateComponent } from "./select-template/select-template.component";
import { ReviewComponent } from "./review/review.component";
import { ShareComponent } from "./share/share.component";
import { TeamComponent } from "./team/team.component";
import { RetrospectivesListComponent } from "./retrospectives-list/retrospectives-list.component";
import { PresentationComponent } from "./presentation/presentation.component";

const routes: Routes = [
  { path: "", component: LoginComponent },
  { path: "signup", component: SignupComponent },
  { path: "idea", component: IdeasComponent, canActivate: [AuthGuardGuard] },
  { path: "home", component: HomeComponent, canActivate: [AuthGuardGuard] },
  { path: "vote", component: VoteComponent, canActivate: [AuthGuardGuard] },
  {
    path: "brainstroming",
    component: BrainstromingComponent,
    canActivate: [AuthGuardGuard],
  },
  { path: "group", component: GroupComponent },
  {
    path: "discussion",
    component: DiscussionComponent,
    canActivate: [AuthGuardGuard],
  },
  { path: "review", component: ReviewComponent, canActivate: [AuthGuardGuard] },
  { path: "share", component: ShareComponent, canActivate: [AuthGuardGuard] },
  { path: "team", component: TeamComponent, canActivate: [AuthGuardGuard] },
  {path :"presentation", component: PresentationComponent},
  {
    path: "select",
    component: SelectTemplateComponent,
    canActivate: [AuthGuardGuard],
  },
  {
    path: "retros",
    component: RetrospectivesListComponent,
    canActivate: [AuthGuardGuard],
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
