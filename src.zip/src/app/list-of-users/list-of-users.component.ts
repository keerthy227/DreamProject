import { Component, OnInit } from '@angular/core';
import { UserserviceService } from '../userservice.service';
import { SessionService } from '../session.service';
import { Session } from '../interfaces/session';
import { Notes} from '../interfaces/notes';
import { AuthServiceService } from '../auth-service.service';

@Component({
  selector: 'app-list-of-users',
  templateUrl: './list-of-users.component.html',
  styleUrls: ['./list-of-users.component.css']
})
export class ListOfUsersComponent implements OnInit {

  constructor(public userservice:UserserviceService, public sessionservice:SessionService,
   public service:AuthServiceService) { }

  
  interval;
  sessionName:any;
  sessionuser:any=[];
  voteCount:any=[];
  voteCountFinal:any=[];
  count:number=0;
  screen:String;
  check:boolean=false;
  userId:number=this.service.loggedUserId;
  sessionId:any=this.sessionservice.sessionID;
   counter = Array;

  ngOnInit() {
   
    //this.getCountOfFinished();
   
  }

  getCountOfFinished(){
    
    this.userservice.getStatusCheck(this.sessionservice.sessionID).subscribe(
      (data)=>{
         console.log(data);
        if(data != null){
          console.log(data);
           for(let i in data){
              if(data[i].userId == this.userId)
                this.screen=data[i].currentScreen;
              if((data[i].role == 'facilitator') && (data[i].userId == this.userId))
                this.check=true;
           }
           this.getUser();
            console.log(this.screen);
        }
       
      },
      (error)=>{
        console.log("error in count");
      }
    );
}

   getUser(){

      this.userservice.getUsers(this.sessionservice.sessionID).subscribe(
        (data)=>{
          this.sessionuser.length=0;
          this.sessionuser=data;
          console.log(this.sessionuser);
          this.voteCountFinal.length=0;
          for(let i in this.sessionuser){
            this.voteCountFinal.push({
              id:this.sessionuser[i].id,
              vote:5,
              userName:this.sessionuser[i].userName,
              displayName:this.sessionuser[i].displayName,
              role:"user",
            });
          }
          this.userservice.getAllUser(this.sessionservice.sessionID).subscribe(
            (data)=>{
              console.log(data);
              for(let index in data){
                if(data[index].role == "facilitator")
                  this.voteCountFinal.find(i=>i.id == data[index].userId).role="facilitator";
              }
            }
          );
      this.userservice.getAllNotes(this.sessionservice.sessionID).subscribe(
      (data:Notes[]) => {
        console.log(data);
          for(let index in data){
            data[index].voteList.forEach(item=> {
              if(this.voteCountFinal.find(i=>i.id == item.userId) != undefined){
              let i=this.voteCountFinal.find(i=>i.id == item.userId).vote;
              this.voteCountFinal.find(i=>i.id == item.userId).vote =i - item.votes;
            }
             
            });
          }
          console.log(this.voteCountFinal);
        });
        document.getElementById("mySidenav").style.width = "250px";
       },
       (error)=>{
         alert("Error occurs in getting users");
       }
     )
   }


  
  numberReturn(length){
    return new Array(length);
  }

color(userId) {
   
  this.count = 0;
  for (let i in this.sessionuser) {
    this.count++;
    if (this.sessionuser[i].id == userId) {

      if (this.count % 10 == 1) {
        return "#ffb3b3";
      }
      if (this.count % 10 == 2) {
        return "#b3b3ff";
      }
      if (this.count % 10 == 3) {
        return "#00e6ac";
      }
      if (this.count % 10 == 4) {
        return "#cc00cc";
      }
      if (this.count % 10 == 5) {
        return "#ff0080";
      }
      if (this.count % 10 == 6) {
        return "#ff9966";
      }
      if (this.count % 10 == 7) {
        return "#ccccb3";
      }
      if (this.count % 10 == 8) {
        return "#dd99ff";
      }
      if (this.count % 10 == 9) {
        return "#b35900";
      }
      if (this.count % 10 == 0) {
        return "#e60073";
      }
    }
  }

}

  

 openNav() {
   this.getCountOfFinished();
    
    
  }
  
  closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

  ngOnDestroy(){
    clearInterval(this.interval);
  }
}
