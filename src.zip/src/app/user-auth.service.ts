import { Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import {environment } from '../environments/environment';
@Injectable({
  providedIn: 'root'
})
export class UserAuthService {
  private baseUrl = "http://localhost:8095/authenticate";
  token: string;
 // role: string;
  constructor(private httpClient: HttpClient) {}

  authenticate(user: String, password: String): Observable<any> {
    let credentials = btoa(user + ":" + password);
    let headers = new HttpHeaders();
    headers = headers.set("Authorization", "Basic " + credentials);
    return this.httpClient.get(this.baseUrl, { headers });
  }

  public setToken(token: string) {
    this.token = token;
  }
  public getToken() {
    return this.token;
  }
  // public setRole(role: string) {
  //   this.role = role;
  // }
  // public getRole() {
  //   return this.role;
  // }
}
