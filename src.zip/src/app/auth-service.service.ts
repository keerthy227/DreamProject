import { Injectable } from "@angular/core";
import { UserAuthService } from "./user-auth.service";
import { Router } from "@angular/router";
import { SessionService } from "./session.service";
@Injectable({
  providedIn: "root",
})
export class AuthServiceService {
  public loggedInUser: boolean = false;
  adminFlag: boolean;
  loggedUserName: string;
  flag: boolean;
  Invalid: boolean = false;
  loggedUserId: number;
  displayName: String;
 public loginCheck:any=false;
  error: string;
  constructor(
    private userAuthService: UserAuthService,
    public router: Router
  ) {}
  getUserName() {
    return this.loggedUserName;
  }
  getUserId() {
    return this.loggedUserId;
  }
  logOut() {
    this.loggedInUser = false;
    this.adminFlag = false;
    this.loggedUserName = "";
    this.userAuthService.setToken("");
    this.router.navigateByUrl("");
  }
  isLogged() {
    return this.loggedInUser;
  }

  authenticateUser(username: string, password: string) {
	  this.loginCheck=true;
    console.log("Authentication called");
    this.userAuthService.authenticate(username, password).subscribe(
      (data: any) => {
		  
        this.userAuthService.setToken(data.token);
        // this.userAuthService.setRole(data.role);
        this.loggedUserName = username;
        this.loggedUserId = data.Id;
        this.displayName = data.displayName;
        console.log(data);
        // let x = data.role;
        // if ( x.toLowerCase() === "admin") {
        //   this.adminFlag = true;
        //   this.loggedInUser = true;
        //   this.router.navigateByUrl("adminHome");
        // } else {
        //   this.adminFlag = false;
        this.loggedInUser = true;
        this.router.navigateByUrl("/team");

        //  }
      },
      (error) => {
        console.log(error);
        if (error.status == 401) {
          this.error = "Invalid user ";
          this.Invalid = true;
		   this.loginCheck=false;
          console.log(this.error + "error");
          this.router.navigateByUrl("/login");
        }
        if (error.status == 404) {
          alert("Username not found");
		   this.loginCheck=false;
        }
      }
    );
  }
  isAdmin() {
    return this.adminFlag;
  }
}
