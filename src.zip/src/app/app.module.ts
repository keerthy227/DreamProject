import {
  BrowserModule,
  HAMMER_GESTURE_CONFIG,
} from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { ReactiveFormsModule } from "@angular/forms";
import { IdeasComponent } from "./ideas/ideas.component";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { ListOfUsersComponent } from "./list-of-users/list-of-users.component";
import { TimerComponent } from "./timer/timer.component";
import { LoginComponent } from "./login/login.component";
import { SignupComponent } from "./signup/signup.component";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { HomeComponent } from "./home/home.component";
import { TemplateComponent } from "./template/template.component";
import { BrainstromingComponent } from "./brainstroming/brainstroming.component";
import { DiscussionComponent } from "./discussion/discussion.component";
import { GroupComponent } from "./group/group.component";
import { VoteComponent } from "./vote/vote.component";
import { DragDropModule } from "@angular/cdk/drag-drop";
import { SelectTemplateComponent } from "./select-template/select-template.component";
import { ReviewComponent } from "./review/review.component";
import { ShareComponent } from "./share/share.component";
import { TeamComponent } from "./team/team.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { DatePipe } from "@angular/common";
import { MatNativeDateModule } from "@angular/material/core";
import { MatFormFieldModule } from "@angular/material/form-field";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { MatSliderModule } from "@angular/material/slider";
import { MatInputModule } from "@angular/material/input";
import { MatStepperModule } from "@angular/material/stepper";
import { RetrospectivesListComponent } from "./retrospectives-list/retrospectives-list.component";
import { PresentationComponent } from './presentation/presentation.component';

@NgModule({
  declarations: [
    AppComponent,
    IdeasComponent,
    ListOfUsersComponent,
    TimerComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    TemplateComponent,
    SelectTemplateComponent,
    BrainstromingComponent,
    DiscussionComponent,
    GroupComponent,
    VoteComponent,
    ReviewComponent,
    ShareComponent,
    TeamComponent,
    RetrospectivesListComponent,
    PresentationComponent,
  ],
  exports: [
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatSliderModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    MatStepperModule,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RouterModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    DragDropModule,
    NgbModule,
    MatNativeDateModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSliderModule,
    MatDatepickerModule,
    MatStepperModule,
  ],
  providers: [DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule {}
