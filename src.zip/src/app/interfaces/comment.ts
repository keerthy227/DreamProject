import { User } from "./user";
import { Notes } from "./notes";
export interface Comment{
    commentId?: number;
    comment?: String;
    commentUser?: User;
    notes?: Notes;
}