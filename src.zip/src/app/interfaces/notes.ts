import {User} from './user';
import {Comment} from './comment';
import { Action } from './action';
import { Vote } from './vote';

export interface Notes{
    notesId?:number;
    notes?:String;
    getNotesId?:number;
    voteList?:Vote[];
    retroSessionId?:String;
    retroSessionName?:String;
    groupId?:number;
    groupName?:String;
    user?:User;
    commentList?:Comment[];
    actionList?:Action[];
}