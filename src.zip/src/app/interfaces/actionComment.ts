import { Action } from './action';
import { User } from './user';


export interface ActionComment{
    actionCommentId?: number;
    comments?: String;
    actionCommentUser?: User;
    action?: Action;
    retroSessionId?:String;
}