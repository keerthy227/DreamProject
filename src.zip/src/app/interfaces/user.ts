import { Comment } from "./comment";
import { Action } from "./action";
import { ActionAssigned } from "./actionassigned";

export interface User{
    id?:number;
    userName?:string;
    password?:string;
    email?:string;
    comments?:Comment;
    actions?:Action;
    actionAssigned?:ActionAssigned;
}