export interface statusCheck{
    id?:number;
    currentScreen?:String;
    userId?:number;
    statusOfScreen?:boolean;
    statusOfNotes?:boolean;
    retroSessionId?:String;
    role?:String;
}