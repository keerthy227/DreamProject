import { User } from "./user";
import { Notes } from "./notes";
import { Session } from "./session";

export interface Action {
    actionId?: number;
    action?: String;
    actionUser?: User;
    notes?: Notes;
    retroSessionId?:String;
    dueDate?:Date;
    completedDate?:Date;
}