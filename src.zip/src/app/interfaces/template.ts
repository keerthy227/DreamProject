export interface Template{
    id?:number;
    templateName?:string;
    noOfColumns?:number;
    topics?:string[];
    icons?:string[];

}