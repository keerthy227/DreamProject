import { Session } from './session';

export interface Team{
    id?:number;
    teamName?:String;
    userId?:number;
    role?:String;
    retroSessions?:Session[];
    userName?:String;
    displayName?:String;
}