import { Notes } from "./notes";

export interface Vote {
    voteId?:number;
    votes?:number;
    notes:Notes;
    userId?:number;
    retroSessionId?:String;
    
}