import { Template } from "./template";
import { Team } from "./Team";
export interface Session {
  id?: number;
  role?: String;
  retroSessionId?: String;
  retroSessionName?: string;
  userId?: number;
  userName?: String;
  template?: Template;
  sessionDate?: Date;
  teamName?: String;
  status?: boolean;
  team?: Team;
}
