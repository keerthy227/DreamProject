import { User } from "./user";
export interface ActionAssigned {
  id?: number;
  actionId?: number;
  actionAssignedUser?: User;
  retroSessionId?: String;
}