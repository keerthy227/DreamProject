export interface Timer{
    id?:number;
    min?:number;
    sessionId?:String;
    setTime?:String;
}