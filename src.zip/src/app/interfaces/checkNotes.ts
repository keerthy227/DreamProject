export interface CheckNotes{
    noteId:any;
    noteColomnId:any;
    dBId:any;
}