export interface Mail{
    fromMail?:String;
    toBeSentMail?:String;
    subject?:String;
    text?:String;
    role?:String;
}