import { Component, OnInit } from "@angular/core";
import { SessionService } from "../session.service";
import { Session } from "../interfaces/session";
import { AuthServiceService } from "../auth-service.service";

@Component({
  selector: "app-retrospectives-list",
  templateUrl: "./retrospectives-list.component.html",
  styleUrls: ["./retrospectives-list.component.css"],
})
export class RetrospectivesListComponent implements OnInit {
  Userretros: Session[];
  teamname: String;
  constructor(
    private service: AuthServiceService,
    private sessionService: SessionService
  ) {}

  ngOnInit() {
    this.teamname = this.sessionService.getteamname;
    this.sessionService
      .getteamsession(this.teamname, this.service.loggedUserId)
      .subscribe((data: Session[]) => {
        this.Userretros = data;
      });
  }
}
